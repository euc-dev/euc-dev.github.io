/*
 * Copyright (c) Omnissa, LLC. All rights reserved.
 * This product is protected by copyright and intellectual property laws in the
 * United States and other countries as well as by international treaties.
 * -- Omnissa Restricted
 */

/*
 * helpers.cpp --
 *
 */

/*
 * Make sure that one of the HORIZON_SDK definitions is defined
 */
#if !defined(HORIZON_SDK_SERVER) && !defined(HORIZON_SDK_CLIENT)
#   error Either HORIZON_SDK_SERVER or HORIZON_SDK_CLIENT must be defined
#endif

#include "stdafx.h"
#include "helpers.h"
#include "horizon_sdk.h"

#if !defined(_WIN32)
#   include <sys/stat.h>
#endif


/*
 *----------------------------------------------------------------------
 *
 * Hzn_Strcpy --
 *
 *    Wrapper for strcpy that checks for buffer overruns.
 *
 * Results:
 *    Same as strcpy.
 *
 * Side effects:
 *    None.
 *
 *----------------------------------------------------------------------
 */
#if !defined(_WIN32)
char *
Hzn_Strcpy(char *buf,       // OUT
           const char *src, // IN
           size_t maxSize)  // IN
{
   int i;

   if (buf == NULL || src == NULL || maxSize <= 0) {
      return NULL;
   }

   for (i = 0; src[i] != '\0' && i < maxSize - 1; ++i) {
      buf[i] = src[i];
   }

   buf[i] = '\0';
   return buf;
}
#endif

/*
 *----------------------------------------------------------------------
 *
 * Function HorizonInstalled --
 *
 * Results:
 *    Returns TRUE if requested version of Horizon is installed
 *
 * Side effects:
 *    None
 *
 *----------------------------------------------------------------------
 */
bool
HorizonInstalled(bool legacy) // IN
{
#if defined(_WIN32)
   HKEY regHive = HKEY_LOCAL_MACHINE;
   const TCHAR *regValue = _T("BuildNumber");
   TCHAR regKey[MAX_PATH];
   DWORD regType = REG_SZ;

   if (legacy) {
      HZN_TCSCPY(regKey, LEGACY_HORIZON_VDM_REG_ROOT);
   } else {
      HZN_TCSCPY(regKey, HORIZON_VDM_REG_ROOT);
   }

#   ifdef HORIZON_SDK_CLIENT
   HZN_TCSCAT(regKey, _T("\\Client"));
#   endif

   /*
    * You need to look in the registry to find where the
    * dll is installed. For 32-bit appliations make sure
    * to look on non-wow side of the registry.
    */
   HKEY hKey = NULL;
   REGSAM regOpenMode = KEY_QUERY_VALUE | (HZN_IS_32_BIT ? KEY_WOW64_64KEY : 0);

   LONG err = ::RegOpenKeyEx(regHive, regKey, 0, regOpenMode, &hKey);
   if (err != ERROR_SUCCESS)
      return false;

   TCHAR regData[1024];
   DWORD regDataSz = sizeof(regData);
   DWORD regDataType = REG_NONE;

   err = ::RegQueryValueEx(hKey, regValue, NULL, &regDataType, (LPBYTE)regData, &regDataSz);
   RegCloseKey(hKey);
   if (err != ERROR_SUCCESS)
      return false;
   if (regDataType != regType)
      return false;

   return true;

#elif defined(__linux__)
   const char *horizonPath = "";
   if (legacy) {
      horizonPath = "/usr/lib/vmware/view/client/vmware-remotemks";
   } else {
      horizonPath = "/usr/lib/omnissa/horizon/client/horizon-protocol";
   }
   struct stat fileinfo;
   return stat(horizonPath, &fileinfo) == 0;

#elif defined(__APPLE__)
   const char *horizonPath = "";
   if (legacy) {
      horizonPath = "/Applications/VMware Horizon Client.app"
                    "/Contents/Resources/VMware RemoteMKS.app"
                    "/Contents/MacOS/vmware-remotemks";
   } else {
      horizonPath = "/Applications/Omnissa Horizon Client.app"
                    "/Contents/Resources/Horizon Protocol.app"
                    "/Contents/MacOS/horizon-protocol";
   }
   struct stat fileinfo;
   return stat(horizonPath, &fileinfo) == 0;

#else
#   error "Unsupported platform"
   return false;
#endif
}


#if defined(_WIN32)
/*
 *----------------------------------------------------------------------
 *
 * Function VDPService_PluginPath --
 *
 *    Generates the registry path for a plugin
 *
 * Results:
 *    Returns TRUE if the plugin path was generated
 *
 * Side effects:
 *    None
 *
 *----------------------------------------------------------------------
 */
bool
VDPService_PluginPath(const TCHAR *token, // IN
                      TCHAR *regPath,     // OUT
                      DWORD regPathSz)    // IN
{
   /*
    * The location in the registry is based on the version of Horizon
    */
   if (OMNISSA_HORIZON_INSTALLED) {
      HZN_TCSCPY_S(regPath, regPathSz, HORIZON_VDPSERVICE_REG_ROOT);

   } else if (LEGACY_HORIZON_INSTALLED) {
      HZN_TCSCPY_S(regPath, regPathSz, LEGACY_HORIZON_VDPSERVICE_REG_ROOT);

   } else {
      return false;
   }

   /*
    * The name of the reg key under "Plugins" doesn't have
    * to be the same as the token, but it's a good idea
    */
   HZN_TCSCAT_S(regPath, regPathSz, _T("\\Plugins\\"));
   HZN_TCSCAT_S(regPath, regPathSz, token);

   return true;
}


/*
 *----------------------------------------------------------------------
 *
 * Function VDPService_RegisterPlugin --
 *
 *    Updates the registry to identify the DLL
 *    as an RDP virtual channel client.
 *
 * Results:
 *    Returns ERROR_SUCCESS
 *
 * Side effects:
 *    None
 *
 *----------------------------------------------------------------------
 */
HRESULT
VDPService_RegisterPlugin(const TCHAR *token) // IN
{
   HKEY regHive = HKEY_LOCAL_MACHINE;
   const TCHAR *regValue = _T("dll");
   TCHAR regKey[MAX_PATH];

   /*
    * The location in the registry is based on the version of Horizon
    */
   if (!VDPService_PluginPath(token, regKey, ARRAYSIZE(regKey))) {
      return VDPSERVICE_REGISTER_PLUGIN_ERROR(0);
   }

   /*
    * Get the path to the current module
    */
   HMODULE hMod = NULL;
   LPCSTR moduleAddress = (LPCSTR)VDPService_RegisterPlugin;
   DWORD moduleFlags =
      GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS | GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT;
   if (!::GetModuleHandleExA(moduleFlags, moduleAddress, &hMod)) {
      return VDPSERVICE_REGISTER_PLUGIN_ERROR(1);
   }

   TCHAR appPath[MAX_PATH];
   if (!::GetModuleFileName(hMod, appPath, ARRAYSIZE(appPath))) {
      return VDPSERVICE_REGISTER_PLUGIN_ERROR(2);
   }

   /*
    * For 32-bit applications make sure
    * to use the non-wow side of the registry.
    */
   REGSAM regOpenMode = KEY_ALL_ACCESS | (HZN_IS_32_BIT ? KEY_WOW64_64KEY : 0);

   /*
    * Open/create the registry key
    */
   LONG regErr;
   HKEY hRegKey;
   DWORD keyCreated;
   regErr = ::RegCreateKeyEx(regHive, regKey, 0, NULL, REG_OPTION_NON_VOLATILE, regOpenMode, NULL,
                             &hRegKey, &keyCreated);
   if (regErr != ERROR_SUCCESS) {
      return VDPSERVICE_REGISTER_PLUGIN_ERROR(3);
   }

   /*
    * Set the path to the DLL
    */
   const BYTE *regData = (const BYTE *)appPath;
   DWORD regDataLen = (DWORD)((::_tcslen(appPath) + 1) * sizeof(TCHAR));

   regErr = ::RegSetValueEx(hRegKey, regValue, 0, REG_SZ, regData, regDataLen);
   if (regErr != ERROR_SUCCESS) {
      ::RegCloseKey(hRegKey);
      return VDPSERVICE_REGISTER_PLUGIN_ERROR(4);
   }

   ::RegCloseKey(hRegKey);
   return ERROR_SUCCESS;
}


/*
 *----------------------------------------------------------------------
 *
 * Function VDPService_UnregisterPlugin --
 *
 *    Removes the registry entries added by VDPService_RegisterPlugin
 *
 * Results:
 *    Returns ERROR_SUCCESS
 *
 * Side effects:
 *    None
 *
 *----------------------------------------------------------------------
 */
HRESULT
VDPService_UnregisterPlugin(const TCHAR *token) // IN
{
   HKEY regHive = HKEY_LOCAL_MACHINE;
   TCHAR regKey[MAX_PATH];

   /*
    * The location in the registry is based on the version of Horizon
    */
   if (!VDPService_PluginPath(token, regKey, ARRAYSIZE(regKey))) {
      return VDPSERVICE_REGISTER_PLUGIN_ERROR(0);
   }

   /*
    * For 32-bit applications make sure
    * to use the non-wow side of the registry.
    */
   REGSAM regOpenMode = KEY_ALL_ACCESS | (HZN_IS_32_BIT ? KEY_WOW64_64KEY : 0);

   /*
    * Remove the plugin registration
    */
   HRESULT regErr = ::RegDeleteKeyEx(regHive, regKey, regOpenMode, 0);

   if (regErr != ERROR_SUCCESS && regErr != ERROR_FILE_NOT_FOUND) {
      return VDPSERVICE_REGISTER_PLUGIN_ERROR(1);
   }

   return ERROR_SUCCESS;
}
#endif