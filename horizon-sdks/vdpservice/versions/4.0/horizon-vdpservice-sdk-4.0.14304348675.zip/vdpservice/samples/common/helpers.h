/*
 * Copyright (c) Omnissa, LLC. All rights reserved.
 * This product is protected by copyright and intellectual property laws in the
 * United States and other countries as well as by international treaties.
 * -- Omnissa Restricted
 */

/*
 * helpers.h --
 *
 */

#pragma once

#ifndef __HELPERS_H__
#   define __HELPERS_H__

#   include <stdio.h>

#   ifdef _WIN32
typedef DWORD VMThreadID;

#   else // !_WIN32

typedef pthread_t VMThreadID;
#      define GetCurrentThreadId() (pthread_self())
#      define GetCurrentProcessId() ((unsigned int)getpid())
#      define Sleep(_interval) usleep(_interval * 1000);
char *Hzn_Strcpy(char *buf, const char *src, size_t maxSize);

#      define _strnicmp strncasecmp
#      define _stricmp strcasecmp
#      define _wcsicmp wcscasecmp
#      define _snprintf snprintf
#      define _vsnprintf vsnprintf
#      define _tcscpy_s strcpy_s
#      define _strdup strdup

#      define HELPER_ARGS(...) , ##__VA_ARGS__

#      ifndef strncpy_s
#         define strncpy_s(_dest, _n, _source, _count)                                             \
            do {                                                                                   \
               strncpy(_dest, _source, (_n) - 1);                                                  \
               _dest[(_n) - 1] = '\0';                                                             \
            } while (false)
#      endif

#      ifndef strcpy_s
#         define strcpy_s(_dest, _n, _source) Hzn_Strcpy(_dest, _source, _n)
#      endif

#      ifndef strcat_s
#         define strcat_s(_dest, _n, _source) strcat(_dest, _source)
#      endif

#      ifndef _snprintf_s
#         define _snprintf_s(_msgp, _msgl, _cnt, _fmt, ...)                                        \
            snprintf(_msgp, _msgl, _fmt HELPER_ARGS(__VA_ARGS__))
#      endif

#      ifndef _vsnprintf_s
#         define _vsnprintf_s(_msgp, _msgl, _cnt, _fmt, _va) vsnprintf(_msgp, _msgl, _fmt, _va)
#      endif
#   endif // ifdef _WIN32


/*
 * HZN_ASSERT
 */
#   define HZN_ASSERT(cond)                                                                        \
      do {                                                                                         \
         if (!(cond)) {                                                                            \
            fprintf(stderr, "%s(%d)@%s: ASSERT(%s)\n", __FILE__, __LINE__, __FUNCTION__, #cond);   \
            exit(1);                                                                               \
         }                                                                                         \
      } while (false)


/*
 * Determine if I'm being compiled as 32 or 64 bit.
 * This is normally done with a preprocessor symbol
 * but I don't want this code to depend on such symbols
 * so that it can be easily added to other projects.
 */
#   define HZN_IS_32_BIT (sizeof(void *) == 4)


/*
 * Define macros for _tcscpy_s()
 * to automatically do the error checking
 */
#   define HZN_TCSCPY_S(dest, szDest, src)                                                         \
      do {                                                                                         \
         if (_tcscpy_s(dest, szDest, src) != 0)                                                    \
            return false;                                                                          \
      } while (false)

#   define HZN_TCSCAT_S(dest, szDest, src)                                                         \
      do {                                                                                         \
         if (_tcscat_s(dest, szDest, src) != 0)                                                    \
            return false;                                                                          \
      } while (false)

#   define HZN_TCSCPY(dest, src)                                                                   \
      do {                                                                                         \
         HZN_TCSCPY_S(dest, ARRAYSIZE(dest), src);                                                 \
      } while (false)

#   define HZN_TCSCAT(dest, src)                                                                   \
      do {                                                                                         \
         HZN_TCSCAT_S(dest, ARRAYSIZE(dest), src);                                                 \
      } while (false)


/*
 * HorizonInstalled --
 * LegacyHorizonInstalled --
 * OmnissaHorizonInstalled --
 *
 *    Determines which version of Horizon is installed; Omnissa or legacy.
 */
bool HorizonInstalled(bool legacy);
#   define LEGACY_HORIZON_INSTALLED HorizonInstalled(true)
#   define OMNISSA_HORIZON_INSTALLED HorizonInstalled(false)


/*
 * These functions are used by plugin registration code
 */
#   if defined _WIN32
/*
 * VDPService_RegisterPlugin --
 * VDPService_UnregisterPlugin --
 *
 *    (Un)Registers a VDPService plugin.
 */
HRESULT VDPService_RegisterPlugin(const TCHAR *token);
HRESULT VDPService_UnregisterPlugin(const TCHAR *token);
bool VDPService_PluginPath(const TCHAR *token, TCHAR *regPath, DWORD regPathSz);

#      define VDPSERVICE_REGISTER_PLUGIN_ERROR(x) ((HRESULT)(0x80040200 + (x)))
#   endif // #if defined _WIN32

#endif // __HELPERS_H__
