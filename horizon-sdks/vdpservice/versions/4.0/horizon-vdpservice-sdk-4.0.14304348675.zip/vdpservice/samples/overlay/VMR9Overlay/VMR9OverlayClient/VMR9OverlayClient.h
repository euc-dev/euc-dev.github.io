/*
 * Copyright (c) Omnissa, LLC. All rights reserved.
 * This product is protected by copyright and intellectual property laws in the
 * United States and other countries as well as by international treaties.
 * -- Omnissa Restricted
 */

/*
 * VMR9OverlayClient.h --
 *
 */

#ifndef VMR9OVERLAYCLIENT_H
#define VMR9OVERLAYCLIENT_H

#if _MSC_VER > 1000
#   pragma once
#endif // _MSC_VER > 1000

#include "resource.h"

#endif // VMR9OVERLAYCLIENT_H
