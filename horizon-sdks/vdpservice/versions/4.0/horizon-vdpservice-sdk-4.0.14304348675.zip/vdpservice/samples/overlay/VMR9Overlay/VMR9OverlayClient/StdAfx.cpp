/*
 * Copyright (c) Omnissa, LLC. All rights reserved.
 * This product is protected by copyright and intellectual property laws in the
 * United States and other countries as well as by international treaties.
 * -- Omnissa Restricted
 */

/*
 * StdAfx.cpp --
 *
 */

#include "stdafx.h"

// TODO: reference any additional headers you need in STDAFX.H
// and not in this file
