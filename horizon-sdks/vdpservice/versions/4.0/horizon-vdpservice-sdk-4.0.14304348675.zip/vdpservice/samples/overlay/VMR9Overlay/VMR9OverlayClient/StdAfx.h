/*
 * Copyright (c) Omnissa, LLC. All rights reserved.
 * This product is protected by copyright and intellectual property laws in the
 * United States and other countries as well as by international treaties.
 * -- Omnissa Restricted
 */

/*
 * StdAfx.h --
 *
 */

#pragma once

/*
 * There is a bug in the C++11 standard that causes a crash with std::mutex.
 * https://stackoverflow.com/questions/78598141/first-stdmutexlock-crashes-in-application-built-with-latest-visual-studio
 */
#ifndef _DISABLE_CONSTEXPR_MUTEX_CONSTRUCTOR
#   define _DISABLE_CONSTEXPR_MUTEX_CONSTRUCTOR
#endif

/*
 * Windows Header Files
 */
#include <windows.h>
#include <objbase.h>

/*
 * C RunTime Header Files
 */
#include <stdio.h>
#include <stdlib.h>
#include <tchar.h>
#include <time.h>
#include <malloc.h>
#include <memory.h>
#include <comdef.h>
#include <commdlg.h>
#include <intrin.h>
#include <string>
#include <mutex>
#include <map>

/*
 * DirectShow Header Files
 */
#undef INTSAFE_E_ARITHMETIC_OVERFLOW
#include <streams.h>
#include <d3d9.h>
#include <vmr9.h>


/*
 * This macro is required by the DShow code
 */
#define FAIL_RET_LOG(x) FAIL_RET_LOGFUNC(LOG, x);
#define FAIL_RET_MSG(x) FAIL_RET_LOGFUNC(FUNCTION_EXIT_MSG, x);

#define FAIL_RET_LOGFUNC(logfunc, x)                                                               \
   do {                                                                                            \
      if (FAILED(hr = (x))) {                                                                      \
         logfunc("%s (failed with 0x%x)", #x, hr);                                                 \
         return hr;                                                                                \
      } else {                                                                                     \
         /* LOG("%s (success with 0x%x)", #x, hr); */                                              \
      }                                                                                            \
   } while (0)


#define LOG_BOOL(b) ((b) ? "TRUE" : "FALSE")
#define LOG_WSTR(s) ((s) ? s : L"(null)")


/*
 * These are defined by both Windows and Horizon
 * although the Window's header file says they
 * aren't used any more.
 */
#undef LODWORD
#undef HIDWORD


/*
 * Local Header Files
 */
#include "helpers.h"
#include "LogUtils.h"


/*
 * Global variables
 */
extern HMODULE g_hModule;


/*
 * This is the token name shared by the guest application
 * and client plugin so that VDPService knows they go together.
 */
#define VMR9_OVERLAY_TOKEN_NAME "VMR9Overlay"


/*
 * Messages passed between guest and client
 */
typedef enum {
   // Guest to client events
   VMR9_OVERLAY_FILE_OPEN,
   VMR9_OVERLAY_FILE_CLOSE,
   VMR9_OVERLAY_PLAYBACK_START,
   VMR9_OVERLAY_PLAYBACK_STOP,
   VMR9_OVERLAY_COPY_IMAGES,

   // Client to guest events
   VMR9_OVERLAY_SET_SIZE
} VMR9OverlayMessages;
