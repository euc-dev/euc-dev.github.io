/*
 * Copyright (c) Omnissa, LLC. All rights reserved.
 * This product is protected by copyright and intellectual property laws in the
 * United States and other countries as well as by international treaties.
 * -- Omnissa Restricted
 */

/*
 * RegisterDll.cpp --
 *
 * Adding these two functions, and exporting them through the .def file,
 * allows us to use RegSvr32.exe to register the DLL by making the
 * necessary updates to the registry.
 *
 */

#include "stdafx.h"
#include "horizon_sdk.h"

/*
 *----------------------------------------------------------------------
 *
 * Function DllRegisterServer --
 *
 *    Updates the registry to identify the DLL
 *    as an RDP virtual channel client.
 *
 * Results:
 *    Returns ERROR_SUCCESS
 *
 * Side effects:
 *    None
 *
 *----------------------------------------------------------------------
 */
HRESULT __stdcall DllRegisterServer()
{
   return VDPService_RegisterPlugin(_T(PINGRPC_TOKEN_NAME));
}


/*
 *----------------------------------------------------------------------
 *
 * Function DllUnregisterServer --
 *
 *    Removes the registry entries added by DllRegisterServer
 *
 * Results:
 *    Returns ERROR_SUCCESS
 *
 * Side effects:
 *    None
 *
 *----------------------------------------------------------------------
 */
HRESULT __stdcall DllUnregisterServer()
{
   return VDPService_UnregisterPlugin(_T(PINGRPC_TOKEN_NAME));
}
