/*
 * Copyright (c) Omnissa, LLC. All rights reserved.
 * This product is protected by copyright and intellectual property laws in the
 * United States and other countries as well as by international treaties.
 * -- Omnissa Restricted
 */

/*
 * PingRPCPlugin.h --
 *
 */
#pragma once

#include "RPCManager.h"


/*
 *----------------------------------------------------------------------
 *
 * class PingRPCPlugin --
 *
 *----------------------------------------------------------------------
 */
class PingRPCPlugin : public RPCPluginInstance {
public:
   PingRPCPlugin(RPCManager *rpcManagerPtr);
   virtual ~PingRPCPlugin();

   void OnInvoke(void *messageCtx);
};


/*
 *----------------------------------------------------------------------
 *
 * class RPCClient --
 *
 *----------------------------------------------------------------------
 */
class RPCClient : public RPCManager {
public:
   RPCClient() : RPCManager(PINGRPC_TOKEN_NAME) {}
   virtual RPCPluginInstance *OnCreateInstance() { return new PingRPCPlugin(this); }
};
