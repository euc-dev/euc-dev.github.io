/*
 * Copyright (c) Omnissa, LLC. All rights reserved.
 * This product is protected by copyright and intellectual property laws in the
 * United States and other countries as well as by international treaties.
 * -- Omnissa Restricted
 */

/*
 * horizon_sdk.h -- common Horizon definitions used in vdpService header files
 *
 */

#ifndef _HORIZON_SDK_H_
#define _HORIZON_SDK_H_

/*
 * HORIZON_SDK_SERVER and HORIZON_SDK_CLIENT are defined by partners
 * when building applications using the Horizon Session Enhancement SDK.
 * They are not defined when compiling official Omnissa Horizon builds.
 */
#if !defined(HORIZON_SDK_SERVER) && !defined(HORIZON_SDK_CLIENT)
#   include "horizon.h"
#   include "horizonPaths.h"
#else

// For finding where vdpService.dll is located
#   if !defined(HORIZON_REG_ROOT)
#      define HORIZON_REG_ROOT _T("Software\\Omnissa")
#   endif

#   if !defined(HORIZON_VDM_REG_ROOT)
#      define HORIZON_VDM_REG_ROOT _T("Software\\Omnissa\\Horizon")
#   endif

// For backward compatibility we need to look at legacy registry tree
#   if !defined(LEGACY_HORIZON_REG_ROOT)
#      define LEGACY_HORIZON_REG_ROOT _T("Software\\VMware, Inc.")
#   endif

#   if !defined(LEGACY_HORIZON_VDM_REG_ROOT)
#      define LEGACY_HORIZON_VDM_REG_ROOT _T("Software\\VMware, Inc.\\VMware VDM")
#   endif

// For registering vdpService plugins
#   if !defined(HORIZON_VDPSERVICE_REG_ROOT)
#      define HORIZON_VDPSERVICE_REG_ROOT HORIZON_VDM_REG_ROOT _T("\\VDPService")
#   endif

#   if !defined(LEGACY_HORIZON_VDPSERVICE_REG_ROOT)
#      define LEGACY_HORIZON_VDPSERVICE_REG_ROOT LEGACY_HORIZON_REG_ROOT _T("\\VMware VDPService")
#   endif


#   include <stddef.h>

#   include <cinttypes>
typedef uint64_t uint64;
typedef int64_t int64;
typedef uint32_t uint32;
typedef int32_t int32;
typedef uint16_t uint16;
typedef int16_t int16;
typedef uint8_t uint8;
typedef int8_t int8;


typedef char Bool;
#   ifndef FALSE
#      define FALSE 0
#   endif
#   ifndef TRUE
#      define TRUE 1
#   endif


typedef struct VMPoint {
   int x, y;
} VMPoint;

#   if defined _WIN32
struct tagRECT;
typedef struct tagRECT VMRect;
#   else
typedef struct VMRect {
   int left;
   int top;
   int right;
   int bottom;
} VMRect;
#   endif // #if defined _WIN32
#endif    // #else !defined(HORIZON_SDK_SERVER) && !defined(HORIZON_SDK_CLIENT)


/*
 * For non-Win32 platforms, we provide a minimalistic GUID implementation to
 * dependency on libuuid.
 *
 * We will generate UUID based on UUID Version4.
 * Version 4 UUIDs use a scheme relying only on random numbers.
 * Version 4 UUIDs have the form xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx
 * where x is any hexadecimal digit and y is one of 8, 9, a, or b.
 * e.g. f47ac10b-58cc-4372-a567-0e02b2c3d479
 * Reference:
 * 1) UUID Wiki Page: http://en.wikipedia.org/wiki/Universally_unique_identifier
 * 2) UUID RFC 4122: http://tools.ietf.org/html/rfc4122
 */
#if !defined(_GUID_STRUCT_) && !defined(_WIN32)
#   define _GUID_STRUCT_
typedef struct _GUID {
   unsigned int field1;
   unsigned short field2;
   unsigned short field3;
   unsigned short field4;
   unsigned char field5[6];
} GUID;
#endif // !defined(_GUID_STRUCT_) && !defined(_WIN32)

#endif // #ifndef _HORIZON_SDK_H_
