/*
 * Copyright (c) Omnissa, LLC. All rights reserved.
 * This product is protected by copyright and intellectual property laws in the
 * United States and other countries as well as by international treaties.
 * -- Omnissa Restricted
 */

/*
 * VDPScreenCapture.h --
 *
 *    This header file is part of a public API and must be self contained.
 *    It can not contain any references to any non-public Horizon header files.
 *
 *    This API will allow a client-side plugin to capture an area of the
 *    remote desktop and provide information about the host/OS window that
 *    contains the desktop.
 */

#ifndef VDPSCREENCAPTURE_H
#define VDPSCREENCAPTURE_H

#include "horizon_sdk.h"
#include "vdpService_guids.h"
#include "vdpOverlay.h"

#ifdef __cplusplus
extern "C" {
#endif

/*
 * GUID for VDPScreenCapture_Interface
 */
VDP_SERVICE_STD_GUID(VDPScreenCapture_Interface_V1, 0x0f01);
VDP_SERVICE_STD_GUID(VDPScreenCapture_Interface_V2, 0x0fa8);
VDP_SERVICE_STD_GUID(VDPScreenCapture_Interface_V3, 0x0fc3);
VDP_SERVICE_STD_GUID(VDPScreenCapture_Interface_V4, 0x0f83);


/*
 * VDPScreenCapture_ContextId --
 *
 */
typedef void *VDPScreenCapture_ContextId;


/*
 * VDP_SCREEN_CAPTURE_ID_NONE --
 *
 *    This value is defined to not be a valid context id.
 */
#define VDP_SCREEN_CAPTURE_ID_NONE ((VDPScreenCapture_ContextId)0)


/*
 * VDPScreenCapture_Error --
 *
 *    List of all possible error codes for the VDPScreenCapture library
 */
typedef enum {
   VDP_SCREEN_CAPTURE_ERROR_SUCCESS,
   VDP_SCREEN_CAPTURE_ERROR_HOST_NOT_READY,
   VDP_SCREEN_CAPTURE_ERROR_HOST_VERSION_ERROR,
   VDP_SCREEN_CAPTURE_ERROR_HOST_ERROR,
   VDP_SCREEN_CAPTURE_ERROR_INVALID_PARAMETER,
   VDP_SCREEN_CAPTURE_ERROR_ALLOCATION_ERROR,
   VDP_SCREEN_CAPTURE_ERROR_NOT_ALLOWED_IN_APP_MODE,
   VDP_SCREEN_CAPTURE_ERROR_READBACK_WINDOW_NOT_READY,
   VDP_SCREEN_CAPTURE_ERROR_READBACK_WINDOW_DESTROYED,
   VDP_SCREEN_CAPTURE_ERROR_UNSUPPORTED,
   VDP_SCREEN_CAPTURE_ERROR_UNSUPPORTED_PROTOCOL,
   VDP_SCREEN_CAPTURE_ERROR_UNSUPPORTED_AGENT,
   VDP_SCREEN_CAPTURE_ERROR_UNSUPPORTED_OPTION,
   VDP_SCREEN_CAPTURE_ERROR_MAX
} VDPScreenCapture_Error;


/*
 * VDPScreenCapture_RemoteError --
 *
 *    List of all possible error codes for
 *    VDPScreenCapture_Sink.v3.OnReadBackWindowRemoteError()
 */
typedef enum {
   /*
    * The remote window tracking is ready (no error).
    */
   VDP_SCREEN_CAPTURE_REMOTE_ERROR_WINDOW_READY,

   /*
    * The remote window tracking failed because
    * the Horizon Agent isn't ready to return images.
    */
   VDP_SCREEN_CAPTURE_REMOTE_ERROR_WINDOW_NOT_READY,

   /*
    * The remote window tracking failed because
    * the remote window was destroyed.
    */
   VDP_SCREEN_CAPTURE_REMOTE_ERROR_WINDOW_DESTROYED,

   /*
    * The remote window tracking failed because
    * the Horizon Agent is tracking too many windows.
    */
   VDP_SCREEN_CAPTURE_REMOTE_ERROR_TRACKING_FULL,

   /*
    * The remote window tracking failed because
    * the requested window does not exist.
    */
   VDP_SCREEN_CAPTURE_REMOTE_ERROR_INVALID_WINDOW,

   /*
    * The remote window tracking failed because the
    * requested window does not belong to process specified.
    */
   VDP_SCREEN_CAPTURE_REMOTE_ERROR_INVALID_PID,

   /*
    * The remote window tracking failed because the
    * Horizon Agent does not support a requested capability.
    */
   VDP_SCREEN_CAPTURE_REMOTE_ERROR_UNSUPPORTED,

   /*
    * The remote window tracking failed because the
    * window on the remote desktop could not be captured.
    */
   VDP_SCREEN_CAPTURE_REMOTE_ERROR_CAPTURE_FAILED,

   VDP_SCREEN_CAPTURE_REMOTE_ERROR_MAX
} VDPScreenCapture_RemoteError;


/*
 * VDPScreenCapture_Rect --
 *
 * It's more efficient for Windows to work with its native RECT
 * but we need something platform independent for the other platforms
 */
#if defined(_WIN32)
#   define VDPScreenCapture_Rect RECT
#else
#   define VDPScreenCapture_Rect VMRect
#endif


/*
 * VDPScreenCapture_HWND --
 *
 * Type used for the remote window handle.  It must be typed as uint64
 * in case you have a 32-bit client connected to a 64-bit agent.
 */
#define VDPScreenCapture_HWND uint64


/*
 * VDPScreenCapture_ReadBackWindowHandle --
 *
 */
typedef void *VDPScreenCapture_ReadBackWindowHandle;


/*
 * VDP_SCREEN_CAPTURE_READBACK_WINDOW_ID_NONE --
 *
 *    This value is defined to not be a valid readback window handle.
 */
#define VDP_SCREEN_CAPTURE_READBACK_WINDOW_HANDLE_NONE ((VDPScreenCapture_ReadBackWindowHandle)0)


/*
 * VDPScreenCapture_ImageHandle --
 *
 *   A handle that uniquely identifies an image returned from ReadBackScreen()
 *
 */
typedef void *VDPScreenCapture_ImageHandle;


/*
 * VDP_SCREEN_CAPTURE_IMAGE_HANDLE_NONE --
 *
 *    This value is defined to not be a valid readback image handle.
 */
#define VDP_SCREEN_CAPTURE_IMAGE_HANDLE_NONE ((VDPScreenCapture_ImageHandle)0)


/*
 * VDPScreenCapture_ReadBackRequestId --
 *
 *   A handle that uniquely identifies a read back request registration.
 *
 */
typedef void *VDPScreenCapture_ReadBackRequestId;


/*
 * VDP_SCREEN_CAPTURE_READBACK_REQUEST_ID_NONE --
 *
 *    This value is defined to not be a valid read back request ID.
 */
#define VDP_SCREEN_CAPTURE_READBACK_REQUEST_ID_NONE ((VDPScreenCapture_ReadBackRequestId)0)


/*
 * VDPScreenCapture_ImageFormat --
 *
 */
typedef enum {
   VDP_SCREEN_CAPTURE_BGRX = 100,
   VDP_SCREEN_CAPTURE_YUVI420
} VDPScreenCapture_ImageFormat;


/*
 * VDPScreenCapture_OverlayOptions --
 *
 *    Determines how overlays are handled during a screen capture
 */
typedef enum {
   /*
    * V2 - the image includes all overlays
    */
   VDP_SCREEN_CAPTURE_OVERLAY_INCLUDE_ALL,

   /*
    * V2 - the image excludes all overlays
    */
   VDP_SCREEN_CAPTURE_OVERLAY_EXCLUDE_ALL,

   /*
    * V2 - the image will exclude overlays marked with
    *    VDP_OVERLAY_UPDATE_FLAG_EXCLUDE_FROM_READ_BACK in
    *    the call to VDPOverlayClient_Interface.v2.Update()
    */
   VDP_SCREEN_CAPTURE_OVERLAY_EXCLUDE_FLAGGED,

   VDP_SCREEN_CAPTURE_OVERLAY_OPTION_MAX
} VDPScreenCapture_OverlayOptions;


/*
 * VDP_SCREEN_CAPTURE_TOPOLOGY_CHANGED flags --
 *
 *    Flags that can be passed to topology changed callback
 *    registered via VDPScreenCapture_Sink.v1.OnTopologyChanged()
 *
 * VDP_SCREEN_CAPTURE_LOCAL_TOPOLOGY_CHANGED --
 *    V2 - Denotes that the local topology has changed.
 */
#define VDP_SCREEN_CAPTURE_LOCAL_TOPOLOGY_CHANGED (1 << 0)

/*
 * VDP_SCREEN_CAPTURE_REMOTE_TOPOLOGY_CHANGED --
 *    V2 - Denotes that the remote topology has changed.
 */
#define VDP_SCREEN_CAPTURE_REMOTE_TOPOLOGY_CHANGED (1 << 1)

/*
 * VDP_SCREEN_CAPTURE_HOST_WINDOWID_CHANGED --
 *    V2 - Denotes that the OS window ID
 *       of the Horizon Client window has changed.
 */
#define VDP_SCREEN_CAPTURE_HOST_WINDOWID_CHANGED (1 << 2)


/*
 * VDP_SCREEN_CAPTURE_READBACK_CAPS_* --
 *
 *    Flags returned from VDPScreenCapture.v4.GetReadBackCapabilities()
 *
 * VDP_SCREEN_CAPTURE_READBACK_CAPS_READBACK_SCREEN --
 *    V2 - Set if ReadBackScreen() is available
 */
#define VDP_SCREEN_CAPTURE_READBACK_CAPS_READBACK_SCREEN (1 << 0)

/*
 * VDP_SCREEN_CAPTURE_READBACK_CAPS_READBACK_WINDOW --
 *    V3 - Set if ReadBackWindow() is available
 */
#define VDP_SCREEN_CAPTURE_READBACK_CAPS_READBACK_WINDOW (1 << 1)

/*
 * VDP_SCREEN_CAPTURE_READBACK_CAPS_VISIBLE_AREA_ONLY --
 *    V4 - Set if ReadBackWindow() w/ VISIBLE_AREA_ONLY is available
 */
#define VDP_SCREEN_CAPTURE_READBACK_CAPS_VISIBLE_AREA_ONLY (1 << 2)

/*
 * VDP_SCREEN_CAPTURE_READBACK_CAPS_AUXILIARY_WINDOWS --
 *    V4 - Set if ReadBackWindowBegin() w/ auxiliary windows is available
 */
#define VDP_SCREEN_CAPTURE_READBACK_CAPS_AUXILIARY_WINDOWS (1 << 3)


/*
 * VDP_SCREEN_CAPTURE_READBACK_BEGIN_* flags --
 *
 *    Flags that can be passed to
 *    VDPScreenCapture_Interface.v3/v4.ReadBackWindowBegin()
 *
 * VDP_SCREEN_CAPTURE_READBACK_BEGIN_VISIBLE_AREA_ONLY --
 *    V3 - Clips the non-visible area of the window.
 *    The area of the window  that is obscured by other
 *    windows is also obscured in the image returned.
 */
#define VDP_SCREEN_CAPTURE_READBACK_BEGIN_VISIBLE_AREA_ONLY (1 << 0)

/*
 * VDP_SCREEN_CAPTURE_READBACK_BEGIN_LOCATION_CHANGED --
 *    V4 - Set if you want to be notified when the location
 *    of the readback window changes.  Only a single event
 *    is queued at a time so the location tracking is closer
 *    to real time but you get fewer location points.
 */
#define VDP_SCREEN_CAPTURE_READBACK_BEGIN_LOCATION_CHANGED (1 << 1)

/*
 * VDP_SCREEN_CAPTURE_READBACK_BEGIN_LOCATION_CHANGED_EX --
 *    V4 - Set if you want to be notified when the location
 *    of the readback window changes.  Every location update
 *    is queued as a separate event.  This can generate a lot
 *    of events but you get a more accurate movement path.
 */
#define VDP_SCREEN_CAPTURE_READBACK_BEGIN_LOCATION_CHANGED_EX (1 << 2)

/*
 * VDP_SCREEN_CAPTURE_READBACK_BEGIN_IMAGE_CHANGED --
 *    V4 - Set if you want to be notified when the image of
 *    the readback window changes.
 */
#define VDP_SCREEN_CAPTURE_READBACK_BEGIN_IMAGE_CHANGED (1 << 3)


/*
 * VDP_SCREEN_CAPTURE_READBACK_* flags --
 *
 *    Flags that can be used in
 *    VDPScreenCapture_ReadBackParameters.v3.flags
 *
 * VDP_SCREEN_CAPTURE_READBACK_MAINTAIN_ASPECT_RATIO --
 *    V3 - maintain the aspect ratio when scaling.
 */
#define VDP_SCREEN_CAPTURE_READBACK_MAINTAIN_ASPECT_RATIO (1 << 0)

/*
 * VDP_SCREEN_CAPTURE_READBACK_SHRINK_ONLY --
 *    V3 - v2.scaledWidth/Height now represents a maximum size;
 *    i.e. scaling will only happen if the size of the image is
 *    larger than given scaled size.
 */
#define VDP_SCREEN_CAPTURE_READBACK_SHRINK_ONLY (1 << 1)

/*
 * VDP_SCREEN_CAPTURE_READBACK_RETURN_TEST_IMAGE --
 *    V3 - Returns a solid color test image.
 */
#define VDP_SCREEN_CAPTURE_READBACK_RETURN_TEST_IMAGE (1 << 30)

/*
 * VDP_SCREEN_CAPTURE_READBACK_WRITE_IMAGE_FILE --
 *    V3 - Writes the returned image to a file.  This allows you
 *    to verify what the API is returning to your application.
 *    This is helpful when tracking down problems in the rendering
 *    pipeline.  The image file is written as follows:
 *    - ReadBackScreen -> %TEMP%\ReadBackScreen.png
 *    - ReadBackWindow -> %TEMP%\ReadBackWindow-<ID>.png
 */
#define VDP_SCREEN_CAPTURE_READBACK_WRITE_IMAGE_FILE (1 << 31)


/*
 * VDPScreenCapture_ReadBackParameters --
 *
 *    This structure is used in the call
 *       to VDPScreenCapture_Interface.v2.ReadBackScreen()
 *       and VDPScreenCapture_Interface.v3.ReadBackWindow()
 */
typedef struct {
#define VDP_SCREEN_CAPTURE_READ_BACK_PARAMETERS_V2 2
#define VDP_SCREEN_CAPTURE_READ_BACK_PARAMETERS_V3 3
#define VDP_SCREEN_CAPTURE_READ_BACK_PARAMETERS 3
   uint32 version;

   struct {
      /*
       * When used with v2.ReadBackScreen(), the area within the
       * remote desktop, in remote topology coordinates, to read.
       * The area may not cross screen boundaries.  Set srcRect
       * to all 0s to read the entire first screen.
       *
       * When used with v3.ReadBackWindow(), the area within the
       * remote window, in remote window coordinates, to read.
       * e.g. X,Y == 0,0 is the top left corner of the remote
       * window.  Set srcRect to all 0s to read the entire window.
       */
      VMRect srcRect;

      /*
       * The format of the returned image.
       */
      VDPScreenCapture_ImageFormat format;

      /*
       * Determine which overlays are included in the read back.
       *
       * See the flags defined in the VDPScreenCapture_OverlayOptions
       * enum for more details.
       *
       * Note: certain overlays are always excluded from the read back.
       * See VDPOverlayClient_Interface.v3.SetRemoteWindow() for details.
       */
      VDPScreenCapture_OverlayOptions overlayOptions;

      /*
       * Determines if the cursor is included in the read back.
       */
      bool includeCursor;

      /*
       * The scaled width/height of the returned image. If either value
       * is 0 no scaling takes places.
       */
      int32 scaledWidth, scaledHeight;

      /*
       * The alignment requirements, in bytes, of the returned image.
       * The pointer to the start of each scan line will be aligned
       * to be a multiple of this value.  Pass 0 for a default / don't
       * care value.  The graphics library used by the Horizon Client
       * must support the value.
       */
      int32 alignment;
   } v2;

   struct {
      /*
       * See VDP_SCREEN_CAPTURE_READBACK_* flags definitions for details.
       */
      uint32 flags;
   } v3;

} VDPScreenCapture_ReadBackParameters;


/*
 * VDPScreenCapture_ImageInfo --
 *
 *    This structure is used in the call to
 *       VDPScreenCapture_Interface.v2.ReadBackScreen()
 */
typedef struct {
/*
 * You must set the version number so that the API knows
 * how big the structure is.  The version number will be
 * updated to reflect what information the API returned.
 */
#define VDP_SCREEN_CAPTURE_IMAGE_INFO_V2 2
#define VDP_SCREEN_CAPTURE_IMAGE_INFO_V4 4
#define VDP_SCREEN_CAPTURE_IMAGE_INFO 4
   uint32 version;

/*
 * The maximum number of planes that the image can contain
 */
#define VDP_SCREEN_CAPTURE_IMAGE_PLANE_MAX 3

   struct {
      /*
       * A unique handle which is passed to ReadBackRelease()
       * to release resources allocated by the image.  Use
       * the pointers in the image array to access the pixels.
       */
      VDPScreenCapture_ImageHandle hImage;

      /*
       * An array with a pointer to the pixels for each plane of the image.
       *    BGRX - image[0] = BGRX plane,  image[1] = NULL,  image[2] = NULL
       *    YUV  - image[0] = Y plane,  image[1] = U plane,  image[2] = V plane
       */
      void *image[VDP_SCREEN_CAPTURE_IMAGE_PLANE_MAX];

      /*
       * An array with the # of bytes, per row, for each plane of the image.
       */
      int32 pitch[VDP_SCREEN_CAPTURE_IMAGE_PLANE_MAX];

      /*
       * The width/height of the image.
       */
      int32 width, height;

      /*
       * The format of the image.
       */
      VDPScreenCapture_ImageFormat format;
   } v2;

   struct {
      /*
       * The location on the remote desktop, in remote
       * topology coordinates, used to read back the image.
       */
      VMRect location;
   } v4;

} VDPScreenCapture_ImageInfo;


/*
 * VDPScreenCapture_ReadBackWindowInfo --
 *
 *    This structure is used in the call to
 *       VDPScreenCapture_Interface.v4.GetReadBackWindowInfo()
 */
typedef struct {
/*
 * You must set the version number so that the API knows
 * how big the structure is.  The version number will be
 * updated to reflect what information the API returned.
 */
#define VDP_SCREEN_CAPTURE_READBACK_WINDOW_INFO_V4 4
#define VDP_SCREEN_CAPTURE_READBACK_WINDOW_INFO 4
   uint32 version;

   struct {
      /*
       * The readback window handle
       */
      VDPScreenCapture_ReadBackWindowHandle hReadBackWindow;

      /*
       * The current state of the readback window
       */
      VDPScreenCapture_RemoteError state;

      /*
       * The parameters passed to v3/v4.ReadBackWindowBegin()
       */
      VDPScreenCapture_HWND hWnd;
      uint32 processId;
      uint32 flags;

      /*
       * The auxiliary window handles and process IDs
       * passed to v4.ReadBackWindowBegin()
       */
      const VDPScreenCapture_HWND *hWndAux;
      const uint32 *processIdAux;
      int32 auxWindowCount;

      /*
       * The location on the remote desktop, in remote
       * topology coordinates of the readback window.
       */
      VMRect location;
   } v4;

} VDPScreenCapture_ReadBackWindowInfo;


/*
 * VDPScreenCapture_ReadBackRequestParams --
 *
 *    This structure is used in the call
 *       to VDPScreenCapture_Interface.v4.ReadBackRequestUpdate()
 */
typedef struct {
#define VDP_SCREEN_CAPTURE_READBACK_REQUEST_INFO_V4 4
#define VDP_SCREEN_CAPTURE_READBACK_REQUEST_INFO 4
   uint32 version;

   struct {
      /*
       * An array with a pointer to the pixels for each plane of the image.
       *    BGRX - image[0] = BGRX plane,  image[1] = NULL,  image[2] = NULL
       *    YUV  - image[0] = Y plane,  image[1] = U plane,  image[2] = V plane
       */
      void *image[VDP_SCREEN_CAPTURE_IMAGE_PLANE_MAX];

      /*
       * An array with the # of bytes, per row, for each plane of the image.
       */
      int32 pitch[VDP_SCREEN_CAPTURE_IMAGE_PLANE_MAX];

      /*
       * The width/height of the image.
       */
      int32 width, height;

      /*
       * The format of the image.  VDPScreenCapture uses an overlay to
       * display the image so the format must be one supported by the
       * VDPOverlay API.  See VDPOverlay_ImageFormat in vdpOverlay.h
       * for more details.
       */
      VDPOverlay_ImageFormat format;

      /*
       * This is the layout mode of the overlay that defines how the
       * image is scaled to fit into the destination rectangle.  See
       * VDPOverlay_LayoutMode in vdpOverlay.h for more details.
       */
      VDPOverlay_LayoutMode layoutMode;

      /*
       * This is the layer of the overlay.  When there are multiple
       * overlays the one with the higher layer is on top.  See
       * VDPOverlay_SetLayer() in vdpOverlay.h for more details.
       */
      uint32 layer;

      /*
       * An array of rectangles, in image coordinates, that define the
       * clip region for the image.  e.g. X,Y == 0,0 is the top left
       * corner of the image.  Pass 0/NULL if there isn't a clip region.
       */
      int32 clipRgnNRects;
      VDPScreenCapture_Rect *clipRgnRects;

      /*
       * The area within the remote desktop, in remote topology coordinates,
       * to place the image. e.g. X,Y == 0,0 is the top left corner of the
       * remote desktop.
       */
      VMRect dstRect;

      /*
       * Flags used when updating the image. See VDP_OVERLAY_UPDATE_FLAG_*
       * in vdpOverlay.h for details.
       */
      uint32 imageFlags;
   } v4;

} VDPScreenCapture_ReadBackRequestParams;


/************************************************************
 *
 * Screen Capture API
 *
 ************************************************************/

/*
 * VDPScreenCapture_Sink --
 *
 *    This structure contains a set of event handers.  The version
 *    field and the function pointers are filled in by the caller
 *    before calling VDPScreenCapture_Interface.v1.Init().
 */
typedef struct {
#define VDP_SCREEN_CAPTURE_SINK_V1 1
#define VDP_SCREEN_CAPTURE_SINK_V2 2
#define VDP_SCREEN_CAPTURE_SINK_V3 3
#define VDP_SCREEN_CAPTURE_SINK_V4 4
#define VDP_SCREEN_CAPTURE_SINK_VERSON 4
   uint32 version;

   /*
    * VDP_SCREEN_CAPTURE_SINK_V1
    */
   struct {
      /*
       * OnTopologyChanged --
       *
       *    This event handler is called when the topology of the Horizon
       *    client has changed.  This is for information only, no action
       *    is required by the plugin.
       */
      void (*OnTopologyChanged)(void *userData,                       // IN - user data
                                VDPScreenCapture_ContextId contextId, // IN - context ID
                                uint32 flags);                        // IN - flags
   } v1;

   /*
    * VDP_SCREEN_CAPTURE_SINK_V2
    */
   struct {
      /*
       * OnNewFrame --
       *
       *    This event handler is called every time the Horizon client renders
       *    a new frame.  This is for information only, no action is required
       *    by the plugin.
       *
       *    Note: this event handler has been deprecated and is never called.
       */
      void (*OnNewFrame)(void *userData,                        // IN - user data
                         VDPScreenCapture_ContextId contextId); // IN - context ID
   } v2;

   /*
    * VDP_SCREEN_CAPTURE_SINK_V3
    */
   struct {
      /*
       * OnReadBackWindowReady --
       *
       *    This event handler is called after v3/v4.ReadBackWindowBegin()
       *    is called to inform the application that the image for the window
       *    is now ready to be captured.  Calling v3.ReadBackWindow() will
       *    return the error VDP_SCREEN_CAPTURE_ERROR_READBACK_WINDOW_NOT_READY
       *    if the window is not yet ready.
       */
      void (*OnReadBackWindowReady)(void *userData,                       // IN - user data
                                    VDPScreenCapture_ContextId contextId, // IN - context ID
                                    VDPScreenCapture_ReadBackWindowHandle hReadBackWindow);

      /*
       * OnReadBackWindowDestroyed --
       *
       *    This event handler is called if the remote desktop window
       *    being tracked is destroyed.  It is not called when
       *    v3.ReadBackWindowEnd() is called.
       */
      void (*OnReadBackWindowDestroyed)(void *userData,                       // IN - user data
                                        VDPScreenCapture_ContextId contextId, // IN - context ID
                                        VDPScreenCapture_ReadBackWindowHandle hReadBackWindow);

      /*
       * OnReadBackWindowRemoteError --
       *
       *    This event handler is called if there is an error when
       *    setting up the window tracking usually due to an error
       *    returned by the Horizon Agent on the remote desktop.
       *    When this event handler is called, v3.OnReadBackWindowReady()
       *    will not be called.  v3.ReadBackWindowEnd() must still be
       *    called to free up resources.
       */
      void (*OnReadBackWindowRemoteError)(
         void *userData,                       // IN - user data
         VDPScreenCapture_ContextId contextId, // IN - context ID
         VDPScreenCapture_ReadBackWindowHandle hReadBackWindow,
         VDPScreenCapture_RemoteError remoteError); // IN - error code
   } v3;

   /*
    * VDP_SCREEN_CAPTURE_SINK_V4
    */
   struct {
      /*
       * OnReadBackWindowLocationChanged --
       *
       *    This event handler is called if the remote desktop window
       *    being tracked is resized or moved.  You must set the flag
       *    VDP_SCREEN_CAPTURE_READBACK_BEGIN_LOCATION_CHANGED/EX in the
       *    call to v3/v4.ReadBackWindowBegin() to receive this event.
       */
      void (*OnReadBackWindowLocationChanged)(
         void *userData,                       // IN - user data
         VDPScreenCapture_ContextId contextId, // IN - context ID
         VDPScreenCapture_ReadBackWindowHandle hReadBackWindow,
         const VMRect *pLocation); // IN

      /*
       * OnReadBackWindowImageChanged --
       *
       *    This event handler is called if the contents of the remote
       *    desktop window being tracked changes; i.e. the pixels in
       *    the window have changed.  You must set the flag
       *    VDP_SCREEN_CAPTURE_READBACK_BEGIN_IMAGE_CHANGED in the
       *    call to v3/v4.ReadBackWindowBegin()to receive this event.
       */
      void (*OnReadBackWindowImageChanged)(void *userData,                       // IN - user data
                                           VDPScreenCapture_ContextId contextId, // IN - context ID
                                           VDPScreenCapture_ReadBackWindowHandle hReadBackWindow);

      /*
       * OnReadBackRequest --
       *
       *    This event handler is called when the Screen Capture API
       *    is requesting content to be included in a read back image.
       */
      void (*OnReadBackRequest)(void *userData,                       // IN - user data
                                VDPScreenCapture_ContextId contextId, // IN - context ID
                                VDPScreenCapture_ReadBackRequestId readBackRequestId,
                                VDPScreenCapture_HWND hWnd);
   } v4;

} VDPScreenCapture_Sink;


/*
 * structure VDPScreenCapture_Interface --
 *
 *    This is the structure returned when
 *       QueryInterface(GUID_VDPScreenCapture_Interface_*) is called
 */
typedef struct {
#define VDP_SCREEN_CAPTURE_INTERFACE_V1 1
#define VDP_SCREEN_CAPTURE_INTERFACE_V2 2
#define VDP_SCREEN_CAPTURE_INTERFACE_V3 3
#define VDP_SCREEN_CAPTURE_INTERFACE_V4 4
#define VDP_SCREEN_CAPTURE_INTERFACE_VERSION 4
   uint32 version;

   /*
    * VDP_SCREEN_CAPTURE_INTERFACE_V1
    */
   struct {
      /*
       * Init --
       *
       *    This function initializes the screen capture library.
       *
       *    sink - contains the function pointers that are called
       *       when events are generated by the screen capture library.
       *
       *    userData - parameter that is passed to event handler whenever
       *       an event is delivered.
       *
       *    pContextId - returns an ID that is used to identify the instance
       *       of the API.  This ID must be passed to all other API functions.
       *       This ID is also passed when calling the sink handlers.
       */
      VDPScreenCapture_Error (*Init)(const VDPScreenCapture_Sink *sink,       // IN
                                     void *userData,                          // IN
                                     VDPScreenCapture_ContextId *pContextId); // OUT


      /*
       * Exit --
       *
       *    Performs clean up operations and releases all allocated resources.
       *
       *    contextId - the ID returned from VDPScreenCapture_Init().
       */
      VDPScreenCapture_Error (*Exit)(VDPScreenCapture_ContextId contextId); // IN


      /*
       * GetLocalTopology --
       *
       *    Retrieves the topology of the local Horizon client.
       *
       *    contextId - the ID returned from VDPScreenCapture_Init().
       *
       *    pBounds - returns a rectangle which contains the bounding box for the
       *       entire Horizon client.  Pass NULL to avoid returning the information.
       *
       *    pszTopology - a pointer to an int32.  On input the value is the size
       *       of the pTopology array which will return the Horizon client topology.
       *       On output the value is the number of rectangles required to hold
       *       the entire Horizon client topology; which may be larger than the size
       *       passed in if the pTopology array is too small to hold the entire
       *       topology.  Passing NULL is treated the same as *pszTopology == 0.
       *
       *    pTopology - a pointer to an array which returns the rectangles that
       *       make up the Horizon client topology.  Can be NULL only if
       *       pszTopology is NULL or *pszTopology == 0.
       */
      VDPScreenCapture_Error (*GetLocalTopology)(VDPScreenCapture_ContextId contextId, // IN
                                                 VDPScreenCapture_Rect *pBounds,       // OUT
                                                 int32 *pszTopology,                   // IN/OUT
                                                 VDPScreenCapture_Rect *pTopology);    // OUT


      /*
       * GetRemoteTopology --
       *
       *    Retrieves the topology of the remote desktop.
       *
       *    contextId - the ID returned from VDPScreenCapture_Init().
       *
       *    pBounds - returns a rectangle which contains the bounding box for the
       *       entire remote desktop.  Pass NULL to avoid returning the information.
       *
       *    pszTopology - a pointer to an int32.  On input the value is the size
       *       of the pTopology array which will return the remote desktop topology.
       *       On output the value is the number of rectangles required to hold the
       *       entire remote desktop topology; which may be larger than the size
       *       passed in if the pTopology array is too small to hold the entire
       *       topology.  Passing NULL is treated the same as *pszTopology == 0.
       *
       *    pTopology - a pointer to an array which returns the rectangles that
       *       make up the remote desktop topology.  Can be NULL only if
       *       pszTopology is NULL or *pszTopology == 0.
       */
      VDPScreenCapture_Error (*GetRemoteTopology)(VDPScreenCapture_ContextId contextId, // IN
                                                  VDPScreenCapture_Rect *pBounds,       // OUT
                                                  int32 *pszTopology,                   // IN/OUT
                                                  VDPScreenCapture_Rect *pTopology);    // OUT


      /*
       * GetHostWindowByRect --
       *
       *    Returns the host window ID that contains the given rectangle.
       *
       *    contextId - the ID returned from VDPScreenCapture_Init().
       *
       *    pRect - the rectangle that determines which host window to return
       *       in local coordinates.  The host window must contain the entire rectangle.
       *
       *    pHostWindow - returns the host window ID.  The host window ID
       *       can change while Horizon is running so it should not be cached.
       */
      VDPScreenCapture_Error (*GetHostWindowByRect)(VDPScreenCapture_ContextId contextId, // IN
                                                    const VDPScreenCapture_Rect *pRect,   // IN
                                                    uintptr_t *pHostWindow);              // OUT


      /*
       * GetHostWindowByPoint --
       *
       *    Returns the host window ID that contains the given point.
       *
       *    contextId - the ID returned from VDPScreenCapture_Init().
       *
       *    x,y - the point that determines which host window to return in
       *       local coordinates.  The host window must contain this point.
       *
       *    pHostWindow - returns the host window ID.  The host window ID
       *       can change while Horizon is running so it should not be cached.
       */
      VDPScreenCapture_Error (*GetHostWindowByPoint)(VDPScreenCapture_ContextId contextId, // IN
                                                     int32 x,                              // IN
                                                     int32 y,                              // IN
                                                     uintptr_t *pHostWindow);              // OUT


      /*
       * MapLocalToRemoteRect --
       *
       *    Maps a rectangle from local coordinates to remote coordinates.
       *
       *    contextId - the ID returned from VDPScreenCapture_Init().
       *
       *    pLocalRect - the rectangle, in local coordinates, that is
       *       mapped to remote coordinates.  The rectangle can not
       *       span multiple local topology rectangles.
       *
       *    pRemoteRect - returns the mapped rectangle in remote coordinates.
       */
      VDPScreenCapture_Error (*MapLocalToRemoteRect)(VDPScreenCapture_ContextId contextId,    // IN
                                                     const VDPScreenCapture_Rect *pLocalRect, // IN
                                                     VDPScreenCapture_Rect *pRemoteRect);     // OUT


      /*
       * MapRemoteToLocalRect --
       *
       *    Maps a rectangle from remote coordinates to local coordinates.
       *
       *    contextId - the ID returned from VDPScreenCapture_Init().
       *
       *    pRemoteRect - the rectangle, in remote coordinates, that
       *       is mapped to local coordinates.  The rectangle can not
       *       span multiple remote topology rectangles.
       *
       *    pLocalRect - returns the mapped rectangle in local coordinates.
       */
      VDPScreenCapture_Error (*MapRemoteToLocalRect)(VDPScreenCapture_ContextId contextId,     // IN
                                                     const VDPScreenCapture_Rect *pRemoteRect, // IN
                                                     VDPScreenCapture_Rect *pLocalRect); // OUT
   } v1;


   /*
    * VDP_SCREEN_CAPTURE_INTERFACE_V2
    */
   struct {
      /*
       * IsApplicationMode --
       *
       *    Determines if the Horizon client is running in "application mode".
       *
       *    "Application mode" also known as "unity mode" or "seamless windows"
       *    runs an application on a remote desktop and only displays the windows
       *    for the application.
       *
       *    Desktop mode shows the entire remote desktop.
       *
       *    When In application mode the topology and readback functions will
       *    return the error VDP_SCREEN_CAPTURE_ERROR_NOT_ALLOWED_IN_APP_MODE.
       *
       *    contextId - the ID returned from VDPScreenCapture_Init().
       *
       *    pIsApplicationMode - Returns TRUE if the Horizon client is in
       *    application mode.
       */
      VDPScreenCapture_Error (*IsApplicationMode)(VDPScreenCapture_ContextId contextId, // IN
                                                  Bool *pIsApplicationMode);            // OUT


      /*
       * ReadBackScreen --
       *
       *    Returns an image with the remote desktop screen contents.  When finished
       *    with the image it must be released by calling v2.ReadBackRelease().
       *
       *    contextId - the ID returned from VDPScreenCapture_Init().
       *
       *    pParams - the input parameters used to determine which part of the
       *       remote desktop to read.
       *
       *    pImageInfo - the resulting image.  You must release the image
       *       by calling v2.ReadBackRelease() with the handle returned in
       *       VDPScreenCapture_ImageInfo.v1.handle
       */
      VDPScreenCapture_Error (*ReadBackScreen)(VDPScreenCapture_ContextId contextId,         // IN
                                               VDPScreenCapture_ReadBackParameters *pParams, // IN
                                               VDPScreenCapture_ImageInfo *pImageInfo);      // OUT


      /*
       * ReadBackRelease --
       *
       *    Releases resources held by the Horizon client to manage the image returned
       *    from v2.ReadBackScreen().
       *
       *    contextId - the ID returned from VDPScreenCapture_Init().
       *
       *    handle - the handle returned from v2.ReadBackScreen() in
       *       VDPScreenCapture_ImageInfo.v1.handle
       */
      VDPScreenCapture_Error (*ReadBackRelease)(VDPScreenCapture_ContextId contextId, // IN
                                                VDPScreenCapture_ImageHandle hImage); // IN
   } v2;


   /*
    * VDP_SCREEN_CAPTURE_INTERFACE_V3
    */
   struct {
      /*
       * IsReadBackWindowSupported --
       *
       *    Determines if the ReadBackWindow interface is supported.
       *    The ReadBackWindow is dependent on the protocol and the
       *    version of the agent to function properly.
       *
       *    Returns VDP_SCREEN_CAPTURE_ERROR_SUCCESS if it is supported.
       *
       *    Returns one of the VDP_SCREEN_CAPTURE_ERROR_UNSUPPORTED_*
       *    error codes if it isn't supported.
       *
       *    Returns VDP_SCREEN_CAPTURE_ERROR_READBACK_WINDOW_NOT_READY
       *    if the ReadBack API is not yet initialized.
       */
      VDPScreenCapture_Error (*IsReadBackWindowSupported)();


      /*
       * ReadBackWindowBegin --
       *
       *    Starts tracking a remote window; e.g. a window on the remote
       *    desktop.
       *
       *    The API requires some time to begin tracking a remote window.
       *    v3.ReadBackWindow() will return the error code
       *    VDP_SCREEN_CAPTURE_ERROR_READBACK_WINDOW_NOT_READY until
       *    it is ready to return images.
       *
       *    The callback VDPScreenCapture_Sink.v3.OnReadBackWindowReady()
       *    will be called when the API is ready to return images.
       *
       *    The callback VDPScreenCapture_Sink.v3.OnReadBackWindowDestroyed()
       *    will be called if the remote window is destroyed while being tracked.
       *
       *    The callback VDPScreenCapture_Sink.v3.OnReadBackWindowRemoteError()
       *    will be called if there is an error when setting up the tracking.
       *
       *    When finished, you must release the resources used to track the
       *    remote window by calling v3.ReadBackWindowEnd().
       *
       *    If there are multiple calls to v3.ReadBackWindowBegin() to track
       *    the same window, each will return a different ReadBackWindow handle.
       *    Each handle will have to released by calling v3.ReadBackWindowEnd().
       *
       *    contextId - the ID returned from VDPScreenCapture_Init().
       *
       *    hWnd - the Windows HWND of the remote window to track.
       *
       *    processId - the Windows process ID associated with the HWND.
       *       An error will be returned if the HWND does not belong to
       *       this process.
       *
       *    flags - options to apply to the read back.
       *       See VDP_SCREEN_CAPTURE_READBACK_BEGIN_* flags for details.
       *
       *    phReadBackWindow - returns a handle to be used with
       *       v3.ReadBackWindow() and v3.ReadBackWindowEnd().  This
       *       handle is also passed to the ReadBackWindow callbacks.
       */
      VDPScreenCapture_Error (*ReadBackWindowBegin)(
         VDPScreenCapture_ContextId contextId,                     // IN
         VDPScreenCapture_HWND hWnd,                               // IN
         uint32 processId,                                         // IN
         uint32 flags,                                             // IN
         VDPScreenCapture_ReadBackWindowHandle *phReadBackWindow); // OUT


      /*
       * ReadBackWindowEnd --
       *
       *    Stops tracking a remote window and releases the associated resources.
       *
       *    contextId - the ID returned from VDPScreenCapture_Init().
       *
       *    hReadBackWindow - the handle returned from v3.ReadBackWindowBegin().
       */
      VDPScreenCapture_Error (*ReadBackWindowEnd)(
         VDPScreenCapture_ContextId contextId,                   // IN
         VDPScreenCapture_ReadBackWindowHandle hReadBackWindow); // IN


      /*
       * ReadBackWindow --
       *
       *    Returns an image with the remote window contents.  When finished
       *    with the image it must be released by calling v2.ReadBackRelease().
       *
       *    contextId - the ID returned from VDPScreenCapture_Init().
       *
       *    hReadBackWindow - the handle returned from v3.ReadBackWindowBegin().
       *
       *    pParams - the input parameters used to determine which part of the
       *       window to read.  Set VDPScreenCapture_ReadBackParameters.v1.srcRect
       *       to zeros to read the entire window.
       *
       *    pImageInfo - the resulting image.  You must release the image
       *       by calling v2.ReadBackRelease() with the handled return in
       *       VDPScreenCapture_ImageInfo.v1.handle
       */
      VDPScreenCapture_Error (*ReadBackWindow)(
         VDPScreenCapture_ContextId contextId,                  // IN
         VDPScreenCapture_ReadBackWindowHandle hReadBackWindow, // IN
         VDPScreenCapture_ReadBackParameters *pParams,          // IN
         VDPScreenCapture_ImageInfo *pImageInfo);               // OUT
   } v3;


   /*
    * VDP_SCREEN_CAPTURE_INTERFACE_V4
    */
   struct {
      /*
       * GetReadBackCapabilities --
       *
       *    Determines the ReadBack API's capabilities; e.g. which features / options
       *    are available.  The features that are available are determine by the Horizon
       *    Agent and Horizon Client versions as well as the remote protocol being used.
       *
       *    Returns VDP_SCREEN_CAPTURE_ERROR_SUCCESS if the caps are returned.
       *    The actual caps returned via the OUT parameter pReadBackCaps.
       *    See VDP_SCREEN_CAPTURE_READBACK_CAPS_* for details.
       *
       *    Returns VDP_SCREEN_CAPTURE_ERROR_READBACK_WINDOW_NOT_READY if the ReadBack
       *    API is not yet initialized.
       */
      VDPScreenCapture_Error (*GetReadBackCapabilities)(uint32 *pReadbackCaps); // OUT

      /*
       * ReadBackWindowBegin --
       *
       *    Starts tracking a remote window; e.g. a window on the remote
       *    desktop.
       *
       *    This function is similiar to v3.ReadBackWindowBegin() but it
       *    provides a way to include auxiliary windows along with the primary
       *    window.  Auxiliary windows are top level window that will be
       *    included with the readback image if they overlap the primary window.
       *
       *    The API requires some time to begin tracking a remote window.
       *    v3.ReadBackWindow() will return the error code
       *    VDP_SCREEN_CAPTURE_ERROR_READBACK_WINDOW_NOT_READY until
       *    it is ready to return images.
       *
       *    The callback VDPScreenCapture_Sink.v3.OnReadBackWindowReady()
       *    will be called when the API is ready to return images.
       *
       *    The callback VDPScreenCapture_Sink.v3.OnReadBackWindowDestroyed()
       *    will be called if the remote window is destroyed while being tracked.
       *
       *    The callback VDPScreenCapture_Sink.v3.OnReadBackWindowRemoteError()
       *    will be called if there is an error when setting up the tracking.
       *
       *    When finished, you must release the resources used to track the
       *    remote window by calling v3.ReadBackWindowEnd().
       *
       *    If there are multiple calls to v3/v4.ReadBackWindowBegin() to track
       *    the same window, each will return a different ReadBackWindow handle.
       *    Each handle will have to released by calling v3.ReadBackWindowEnd().
       *    But the first call defines the parameters and the subsequent calls
       *    must provide the same parameters, including the list of auxiliary
       *    windows.
       *
       *    contextId - the ID returned from VDPScreenCapture_Init().
       *
       *    hWnd - the Windows HWND of the remote window to track.
       *
       *    processId - the Windows process ID associated with the HWND.
       *       An error will be returned if the HWND does not belong to
       *       this process.
       *
       *    hWndAux - an array of Windows HWNDs to include with the readback
       *       image.  These images will only be included with the readback
       *       image if they overlap the primary window.
       *
       *    processIdAux - an array of process IDs associated with the
       *       corresponding hWndAux.  An error will be returned if the HWND
       *       does not belong to the corresponding process.
       *
       *    auxWindowCount - The count of auxiliary windows in the hWndAux array
       *       and process IDs in the processIdAux array.  hWndAux and processIdAux
       *       may be NULL if auxWindowCount is 0.
       *
       *    flags - options to apply to the read back.
       *       See VDP_SCREEN_CAPTURE_READBACK_BEGIN_* flags for details.
       *
       *    phReadBackWindow - returns a handle to be used with
       *       v3.ReadBackWindow() and v3.ReadBackWindowEnd().  This
       *       handle is also passed to the ReadBackWindow callbacks.
       */
      VDPScreenCapture_Error (*ReadBackWindowBegin)(
         VDPScreenCapture_ContextId contextId,                     // IN
         VDPScreenCapture_HWND hWnd,                               // IN
         uint32 processId,                                         // IN
         VDPScreenCapture_HWND *hWndAux,                           // IN
         uint32 *processIdAux,                                     // IN
         int32 auxWindowCount,                                     // IN
         uint32 flags,                                             // IN
         VDPScreenCapture_ReadBackWindowHandle *phReadBackWindow); // OUT

      /*
       * GetReadBackWindowInfo --
       *
       *    Retrieves information about the given readback window including
       *    state, location, etc.
       *
       *    Returns VDP_SCREEN_CAPTURE_ERROR_SUCCESS on success.  It doesn't mean
       *    that the readback window is in the READY state it just means that
       *    information was returned.  The information about the readback window
       *    is returned via the OUT parameter pReadbackWindowInfo.
       *
       *    contextId - the ID returned from VDPScreenCapture_Init().
       *
       *    hReadBackWindow - the handle returned from v3.ReadBackWindowBegin().
       *
       *    pReadbackWindowInfo - the information about the readback window.
       */
      VDPScreenCapture_Error (*GetReadBackWindowInfo)(
         VDPScreenCapture_ContextId contextId,                      // IN
         VDPScreenCapture_ReadBackWindowHandle hReadBackWindow,     // IN
         VDPScreenCapture_ReadBackWindowInfo *pReadbackWindowInfo); // OUT

      /*
       * RegisterForReadBackRequests --
       *
       *    Registers for screen and window read back requests.  When
       *    v2.ReadBackScreen() or v3.ReadBackWindow() is called the Screen
       *    Capture API will issue a callback where an image can be provided
       *    so that it is included in the read back image.
       *
       *    VDPScreenCapture_Sink.v4.OnReadBackRequest() will be invoked when a
       *    read back of a screen or window is being done.  The callback can then
       *    provide an image to be included in the read back image returned by
       *    by calling v4.ReadBackRequestUpdate().
       *
       *    Each registration can provide an image for a single area of the screen.
       *    If you have multiple areas of the screen that need to be updated then
       *    you will need to register for multiple callbacks.  This applies even
       *    if there are multiple areas associated with the same window; in this
       *    case that window would have to be registered multiple times.
       *
       *    contextId - the ID returned from VDPScreenCapture_Init().
       *
       *    hWnd - the Windows HWND of a window on the remote desktop.  If set to
       *       NULL then you will only receive callbacks when v2.ReadBackScreen()
       *       is called.  If set to non-NULL you will receive callbacks for
       *       v2.ReadBackScreen() as well as calls to v3.ReadBackWindow() with a
       *       matching window handle.
       *
       *    pReadBackRequestId - returns an ID to be used with v4.CaptureRequestUpdate()
       *       and v4.UnregisterForReadBackRequests().  This ID is also passed to the
       *       VDPScreenCapture_Sink.v4.OnReadBackRequest() callback.
       */
      VDPScreenCapture_Error (*RegisterForReadBackRequests)(
         VDPScreenCapture_ContextId contextId,                    // IN
         VDPScreenCapture_HWND hWnd,                              // IN
         VDPScreenCapture_ReadBackRequestId *pReadBackRequestId); // OUT


      /*
       * UnregisterForReadBackRequests --
       *
       *    Unregisters a read back request and releases its resources.
       *
       *    contextId - the ID returned from VDPScreenCapture_Init().
       *
       *    readBackRequestId - the ID returned from v4.RegisterForReadBackRequests().
       */
      VDPScreenCapture_Error (*UnregisterForReadBackRequests)(
         VDPScreenCapture_ContextId contextId,                  // IN
         VDPScreenCapture_ReadBackRequestId readBackRequestId); // IN


      /*
       * ReadBackRequestUpdate --
       *
       *    Provides an image to include in a read back image.  While this function can
       *    be called at any time, it is normally called during the v4.OnReadBackRequest()
       *    callback to provide an image.  A copy of the image is made and is used in all
       *    further read back requests until the image is either replaced or removed by
       *    the next call to v4.ReadBackRequestUpdate().
       *
       *    contextId - the ID returned from VDPScreenCapture_Init().
       *
       *    readBackRequestId - the ID returned from v4.RegisterForReadBackRequests().
       *
       *    pRequestParams - a structure that contains the image to be included in
       *    a read back screen or window capture image.  Pass NULL to remove any
       *    previously set image.
       */
      VDPScreenCapture_Error (*ReadBackRequestUpdate)(
         VDPScreenCapture_ContextId contextId,                    // IN
         VDPScreenCapture_ReadBackRequestId readBackRequestId,    // IN
         VDPScreenCapture_ReadBackRequestParams *pRequestParams); // IN
   } v4;

} VDPScreenCapture_Interface;

#ifdef __cplusplus
}
#endif

#endif /* VDPSCREENCAPTURE_H */
