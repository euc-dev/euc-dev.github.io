/*
 * Copyright (c) Omnissa, LLC. All rights reserved.
 * This product is protected by copyright and intellectual property laws in the
 * United States and other countries as well as by international treaties.
 * -- Omnissa Restricted
 */

/*
 * vdpObserverNameDefs.h --
 *
 *    This header file defines the names registered to
 *    VDPService_ObserverInterface used by components which try to communicate
 *    through the interface.
 */


// Observer name for sending folder redirection command from remotemks to plugin
#define FOLDER_REDIRECTION_CMD "FORLDER_REDIRECTION_CMD"

// Observer name for sending folder redirection notification from plugin to remotemks
#define FOLDER_REDIRECTION_NOTIFICATION "FOLDER_REDIRECTION_NOTIFICATION"

// Observer name for sending Geolocation redirection command from remotemks to plugin
#define GEOLOCATION_REDIRECTION_CMD "GEOLOCATION_REDIRECTION_CMD"

// Observer name for sending Geolocation redirection notification from plugin to remotemks
#define GEOLOCATION_REDIRECTION_NOTIFICATION "GEOLOCATION_REDIRECTION_NOTIFICATION"

// Observer name for sending rde common command from remotemks to plugin
#define RDE_COMMON_GENERIC_CMD "RDE_COMMON_GENERIC_CMD"

// Observer name for sending rde common command from plugin to remotemks
#define RDE_COMMON_GENERIC_NOTIFICATION "RDE_COMMON_GENERIC_NOTIFICATION"

// Observer name for sending html5 messages between plugin and remotemks
#define HTML5_REDIRECTION_MSG "HTML5_REDIRECTION_MSG"

// Observer name for sending SDR command from remotemks to plugin
#define SDR_REDIRECTION_CMD "SDR_REDIRECTION_CMD"

// Observer name for sending SDR notification from plugin to remotemks
#define SDR_REDIRECTION_NOTIFICATION "SDR_REDIRECTION_NOTIFICATION"

// Observer name for sending folder redirection command from remotemks to plugin
#define SCREEN_CAPTURE_CMD "SCREEN_CAPTURE_CMD"

// Observer name for sending folder redirection notification from plugin to remotemks
#define SCREEN_CAPTURE_NOTIFICATION "SCREEN_CAPTURE_NOTIFICATION"

// Observer name for sending fido2 redirection command from remotemks to plugin
#define FIDO2_REDIRECTION_CMD "FIDO2_REDIRECTION_CMD"

// Observer name for sending fido2 notification from plugin to remotemks
#define FIDO2_REDIRECTION_NOTIFICATION "FIDO2_REDIRECTION_NOTIFICATION"
