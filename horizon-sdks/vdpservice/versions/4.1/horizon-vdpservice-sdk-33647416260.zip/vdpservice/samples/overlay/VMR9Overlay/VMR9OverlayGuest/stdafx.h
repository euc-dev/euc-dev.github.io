/*
 * Copyright (c) Omnissa, LLC. All rights reserved.
 * This product is protected by copyright and intellectual property laws in the
 * United States and other countries as well as by international treaties.
 * -- Omnissa Restricted
 */

/*
 * StdAfx.h --
 *
 */

#pragma once
#include "targetver.h"
#include "..\VMR9OverlayClient\StdAfx.h"
