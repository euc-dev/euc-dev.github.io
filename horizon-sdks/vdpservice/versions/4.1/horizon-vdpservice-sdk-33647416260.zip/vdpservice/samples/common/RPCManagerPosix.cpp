/*
 * Copyright (c) Omnissa, LLC. All rights reserved.
 * This product is protected by copyright and intellectual property laws in the
 * United States and other countries as well as by international treaties.
 * -- Omnissa Restricted
 */

/*
 * RPCManagerPosix.cpp --
 *
 */

#include "stdafx.h"
#include "RPCManager.h"


/*
 *----------------------------------------------------------------------
 *
 * RPCManager::AllowRunAsServer --
 *
 *    Whether the RPCManager is allowed to run as server.
 *
 * Results:
 *    Returns false (non-Windows Agent not supported).
 *
 * Side Effects:
 *    None.
 *
 *----------------------------------------------------------------------
 */

bool
RPCManager::AllowRunAsServer()
{
   return false;
}


/*
 *----------------------------------------------------------------------
 *
 * RPCManager::RMWaitForMultipleEvents --
 *
 *    This method waits for the given event to become signaled.  While
 *    waiting it ensures that RPC is being given timeslices so that it
 *    can do its work.
 *
 * Results:
 *    Returns true if an event was signaled.  If an event was signalled
 *    then the index of the event is returned via the OUT parameter <pEventIndex>
 *
 * Side Effects:
 *    None.
 *
 *----------------------------------------------------------------------
 */

bool
RPCManager::RMWaitForMultipleEvents(int nEvents,      // IN
                                    HANDLE *hEvents,  // IN
                                    bool waitAll,     // IN
                                    uint32 msTimeout, // IN
                                    int *pEventIndex) // OUT
{
   return false;
}


/*
 *----------------------------------------------------------------------
 *
 * RPCPluginInstance::InitializeEventsAndMutexes --
 *
 *    Creates and initializes the Events and Mutexes required.
 *
 * Results:
 *    None.
 *
 * Side Effects:
 *    None.
 *
 *----------------------------------------------------------------------
 */

void
RPCPluginInstance::InitializeEventsAndMutexes()
{
   m_hReadyEvent = NULL;
   m_hChannelFailed = NULL;
   m_pendingMsgMutex = NULL;
   m_pendingMsgEvent = NULL;
}


/*
 *----------------------------------------------------------------------
 *
 * RPCPluginInstance::CloseEventsAndMutexes --
 *
 *    Closes the Events and Mutexes used by this instance.
 *
 * Results:
 *    None.
 *
 * Side Effects:
 *    None.
 *
 *----------------------------------------------------------------------
 */

void
RPCPluginInstance::CloseEventsAndMutexes()
{}


/*
 *----------------------------------------------------------------------
 *
 * RPCPluginInstance::RMLockMutex --
 *
 *    Locks the given mutex.
 *
 * Results:
 *    None.
 *
 * Side Effects:
 *    None.
 *
 *----------------------------------------------------------------------
 */

void
RPCPluginInstance::RMLockMutex(HANDLE hMutex) // IN
{}


/*
 *----------------------------------------------------------------------
 *
 * RPCPluginInstance::RMUnlockMutex --
 *
 *    Unlocks the given mutex.
 *
 * Results:
 *    None.
 *
 * Side Effects:
 *    None.
 *
 *----------------------------------------------------------------------
 */

void
RPCPluginInstance::RMUnlockMutex(HANDLE hMutex) // IN
{}


/*
 *----------------------------------------------------------------------
 *
 * RPCPluginInstance::RMSetEvent --
 *
 *    Sets the given event.
 *
 * Results:
 *    None.
 *
 * Side Effects:
 *    None.
 *
 *----------------------------------------------------------------------
 */

void
RPCPluginInstance::RMSetEvent(HANDLE hEvent) // IN
{}


/*
 *----------------------------------------------------------------------
 *
 * RPCPluginInstance::RMResetEvent --
 *
 *    Resets the given event.
 *
 * Results:
 *    None.
 *
 * Side Effects:
 *    None.
 *
 *----------------------------------------------------------------------
 */

void
RPCPluginInstance::RMResetEvent(HANDLE hEvent) // IN
{}
