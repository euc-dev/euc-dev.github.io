/*
 * Copyright (c) Omnissa, LLC. All rights reserved.
 * This product is protected by copyright and intellectual property laws in the
 * United States and other countries as well as by international treaties.
 * -- Omnissa Restricted
 */

/*
 * stdafx.h --
 *
 */

#pragma once

/*
 * There is a bug in the C++11 standard that causes a crash with std::mutex.
 * https://stackoverflow.com/questions/78598141/first-stdmutexlock-crashes-in-application-built-with-latest-visual-studio
 */
#ifndef _DISABLE_CONSTEXPR_MUTEX_CONSTRUCTOR
#   define _DISABLE_CONSTEXPR_MUTEX_CONSTRUCTOR
#endif

#ifdef _WIN32
#   ifndef WIN32_LEAN_AND_MEAN
#      define WIN32_LEAN_AND_MEAN
#   endif

#   include "targetver.h"
#   include <windows.h>
#   include <tchar.h>

#else // _WIN32

#   ifndef USE_WIN_DWORD_RANGE
#      define USE_WIN_DWORD_RANGE
#   endif

#   include "wintypes.h"
#endif // _WIN32

#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <mutex>

#include "helpers.h"
#include "LogUtils.h"

#define PINGRPC_TOKEN_NAME "PingRPC"
#define PINGRPC_MESSAGE "PING"
