/*
 * Copyright (c) Omnissa, LLC. All rights reserved.
 * This product is protected by copyright and intellectual property laws in the
 * United States and other countries as well as by international treaties.
 * -- Omnissa Restricted
 */

#ifndef WINTYPES_H
#   define WINTYPES_H

#   include <wchar.h>
#   include <string>
#   ifdef __APPLE__
#      include "objc/objc.h"
#   endif
#   ifndef TRUE
#      define TRUE 1
#   endif
#   ifndef FALSE
#      define FALSE 0
#   endif
#   ifndef ARRAYSIZE
#      define ARRAYSIZE(a) (sizeof(a) / sizeof(a[0]))
#   endif

typedef unsigned char BYTE;
typedef BYTE *PBYTE;
#   ifndef __APPLE__
typedef int BOOL;
#   endif
typedef BYTE BOOLEAN;
typedef char CHAR;
typedef char CCHAR;
typedef long LONG;

#   ifndef USE_WIN_DWORD_RANGE
#      ifdef __APPLE__
typedef uint32_t DWORD;
#      else
typedef unsigned long DWORD;
#      endif
#   else
typedef unsigned int DWORD;
#   endif

typedef void *HANDLE;
typedef int INT;
typedef char *LPSTR;
typedef void *LPVOID;
typedef DWORD *LPDWORD;
typedef CHAR *LPSTR;
typedef char *PCHAR;
typedef unsigned long *PULONG;
typedef void *PVOID;
typedef short SHORT;
typedef unsigned char UCHAR;
typedef UCHAR *PUCHAR;
typedef unsigned int UINT;
typedef unsigned long long ULONG64;
typedef unsigned int ULONG32;
typedef unsigned long ULONG;
typedef ULONG HRESULT;
typedef unsigned int UINT32;
typedef UINT32 *PUINT32;
typedef int INT32;
typedef unsigned short UINT16;
typedef unsigned char UINT8;
typedef unsigned short USHORT;
typedef void VOID;
typedef const CHAR *LPCSTR;
typedef void *HMODULE;
typedef unsigned short WORD;

typedef DWORD ACCESS_MASK;
typedef ACCESS_MASK *PACCESS_MASK;

/* Check whether the compiler turns on the -fshort-wchar flag.
 * In Android WCHAR_MAX is defined as INT_MAX in wchar.h, the ndk compiler
 * won't use the value of INT_MAX for the pre-compile condition check, so add
 * check for __ANDROID__ macro since it's known that wchar_t is 4-Byte in
 * Android.
 */
#   if defined __ANDROID__ || WCHAR_MAX > 0xFFFFu
/*
 * The wchar_t i.e. widechar implementation is platform and compiler
 * dependent. The wchar_t is 2-byte for VC++ & 4-Byte for G++.
 * Since few WTS functions (QuerySessionInformationA, QuerySessionInformationW)
 * expect input in widechar format and since the server is Windows-based,
 * it is the responsibility of client to construct a widechar string as
 * expected by Windows and then send it over pcoip.
 * We use a custom datatype - LWSTR - which is unsigned short (2-byte) for G++.
 */
typedef unsigned short LWSTR;
typedef unsigned short WCHAR;
typedef WCHAR *PWSTR;
typedef LWSTR *LPWSTR;

#   else // for WCHAR

typedef wchar_t WCHAR;
typedef WCHAR *PWSTR;
typedef WCHAR LWSTR;
typedef WCHAR *LPWSTR;

#   endif // for WCHAR

#   define FAR
#   define CALLBACK

typedef unsigned long long __int64;
#   define __int32 uint32_t
#   define uint32 uint32_t
#   define int32 int32_t

#   if defined(_WIN64)
typedef unsigned __int64 UINT_PTR;
#   else
typedef unsigned int UINT_PTR;
#   endif

#   if defined(_WIN64)
typedef unsigned __int64 ULONG_PTR;
#   else
typedef unsigned long ULONG_PTR;
#   endif

typedef ULONG_PTR SIZE_T;

#   if defined(_WIN64)
typedef __int64 LONG_PTR;
#   else
typedef long LONG_PTR;
#   endif

typedef HANDLE HKEY;
typedef HANDLE HWND;

typedef UINT_PTR WPARAM;
typedef LONG_PTR LPARAM;

/*
 * Definition of LPTSTR from WinNT.h
 */
#   ifdef UNICODE
typedef LPWSTR LPTSTR;
#   else
typedef LPSTR LPTSTR;
#   endif

#   ifdef UNICODE
typedef LPCWSTR LPCTSTR;
#   else
typedef LPCSTR LPCTSTR;
#   endif

/*
 * Below #define is taken from file: bora/public/vm_windefs.h
 */
#   define WAIT_TIMEOUT 258L

/*
 * MS defined constant
 */
#   define MAX_COMPUTERNAME_LENGTH 64

/*
 * #define _ASSERT here - the definition is taken from -
 * $TOOLCHAIN/wine/wine-1.4.1/include/msvcrt/crtdbg.h
 */
#   define _ASSERT(expr) assert(expr)

#   define _snprintf snprintf

#   ifndef INVALID_HANDLE_VALUE
#      define INVALID_HANDLE_VALUE ((HANDLE) - 1)
#   endif

#   ifndef WTS_CURRENT_SESSION
#      define WTS_CURRENT_SESSION ((DWORD) - 1)
#   endif

#   define _stricmp strcasecmp
#   define _wcsicmp wcscasecmp

#   define VCAPITYPE

#   define __cdecl

#   define NTAPI
#   define WINAPI
#   define IN
#   define OUT
#   define INFINITE UINT_MAX


typedef LONG NTSTATUS;
#   define STATUS_SUCCESS 0x00000000
#   define STATUS_NOTIFY_ENUM_DIR 0x0000010C
#   define STATUS_DEVICE_BUSY 0x80000011
#   define STATUS_NO_MORE_FILES 0x80000006
#   define STATUS_UNSUCCESSFUL 0xC0000001
#   define STATUS_NOT_IMPLEMENTED 0xC0000002
#   define STATUS_INVALID_HANDLE 0xC0000008
#   define STATUS_INVALID_PARAMETER 0xC000000D
#   define STATUS_NO_SUCH_FILE 0xC000000F
#   define STATUS_END_OF_FILE 0xC0000011
#   define STATUS_NO_MEMORY 0xC0000017
#   define STATUS_ACCESS_DENIED 0xC0000022
#   define STATUS_BUFFER_TOO_SMALL 0xC0000023
#   define STATUS_OBJECT_NAME_NOT_FOUND 0xC0000034
#   define STATUS_OBJECT_NAME_COLLISION 0xC0000035
#   define STATUS_LOCK_NOT_GRANTED 0xC0000055
#   define STATUS_DISK_FULL 0xC000007F
#   define STATUS_FILE_IS_A_DIRECTORY 0xC00000BA
#   define STATUS_NOT_A_DIRECTORY 0xC0000103
#   define STATUS_CANCELLED 0xC0000120
#   define STATUS_DEVICE_REMOVED 0xC00002B6
#   define STATUS_DIRECTORY_NOT_EMPTY 0xC0000101
#   ifndef MAX_PATH
#      define MAX_PATH 256
#   endif

#   ifndef ERROR_SUCCESS
#      define ERROR_SUCCESS 0
#   endif

/*
 * FILETIME structure definition.
 * Reference: http://msdn.microsoft.com/en-us/library/windows/desktop/ms724284(v=vs.85).aspx
 */
typedef struct _FILETIME {
   DWORD dwLowDateTime;
   DWORD dwHighDateTime;
} FILETIME, *PFILETIME;

typedef std::string _bstr_t;

typedef struct _SECURITY_ATTRIBUTES {
   DWORD nLength;
   LPVOID lpSecurityDescriptor;
#   ifndef __APPLE__
   BOOL bInheritHandle;
#   else
   bool bInheritHandle;
#   endif
} SECURITY_ATTRIBUTES, *PSECURITY_ATTRIBUTES, *LPSECURITY_ATTRIBUTES;

#   define WAIT_OBJECT_0 ((STATUS_WAIT_0) + 0)
#   define STATUS_WAIT_0 ((DWORD)0x00000000L)

typedef struct tagPOINT {
   LONG x;
   LONG y;
} POINT, *PPOINT;

#   if !defined(__i386__)
typedef __int64 LONGLONG;
#   else
typedef long long int LONGLONG;
#   endif

typedef struct tagMSG {
   HWND hwnd;
   UINT message;
   WPARAM wParam;
   LPARAM lParam;
   DWORD time;
   POINT pt;
} MSG, *PMSG, *LPMSG;

typedef union _LARGE_INTEGER {
   struct {
      /*
       * MSDN defines the LowPart and HighPart as DWORD and LONG,
       * but for gcc/llvm DWORD and LONG will be 64-bits for 64-bits
       * target, which is not the actual size Windows expected.
       */
      INT32 LowPart;
      INT32 HighPart;
   };
   struct {
      INT32 LowPart;
      INT32 HighPart;
   } u;
   LONGLONG QuadPart;
} LARGE_INTEGER, *PLARGE_INTEGER;

typedef struct _LSA_UNICODE_STRING {
   USHORT Length;
   USHORT MaximumLength;
   PWSTR Buffer;
} LSA_UNICODE_STRING, *PLSA_UNICODE_STRING, UNICODE_STRING, *PUNICODE_STRING;


/*
 * Replace some very common MSDN functions with their equivalent Linux ones.
 */
#   define _strnicmp strncasecmp
#   define _vsnprintf vsnprintf
#   define _strdup strdup
#   define Sleep(_interval) usleep(_interval * 1000);

/*
 * Below #defines are copied over from vdpService/lib/common/linux/stdafx.h
 */

#   define strnicmp(str1, str2, size) strncasecmp(str1, str2, size)

#   define strncpy_s(_dest, _n, _source, _count)                                                   \
      {                                                                                            \
         strncpy(_dest, _source, (_n) - 1);                                                        \
         _dest[(_n) - 1] = '\0';                                                                   \
      }

#   define _snprintf_s(_msgp, _msgl, _cnt, _fmt, ...) snprintf(_msgp, _msgl, _fmt, __VA_ARGS__)

#   ifdef __APPLE__
#      define _vsnprintf_s(_msgp, _msgl, _cnt, _fmt, _va) ::Str_Vsnprintf(_msgp, _msgl, _fmt, _va)
#   else
#      define _vsnprintf_s(_msgp, _msgl, _cnt, _fmt, _va) vsnprintf(_msgp, _msgl, _fmt, _va)
#   endif

/*
 * Socket constants required by VMSocket class.
 */
#   define INVALID_SOCKET 0
#   define SOCKET_ERROR -1

#endif

#ifndef __APPLE__
#   define interface struct
#endif
#define E_OUTOFMEMORY 0x8007000E
#define S_OK 0x00000000

#define NT_SUCCESS(Status) (((NTSTATUS)(Status)) >= 0)
#define ZeroMemory(Destination, Length) memset((Destination), 0, (Length))

#define FILE_READ_DATA (0x0001)      // file & pipe
#define FILE_LIST_DIRECTORY (0x0001) // directory

#define FILE_WRITE_DATA (0x0002) // file & pipe
#define FILE_ADD_FILE (0x0002)   // directory

#define FILE_APPEND_DATA (0x0004)          // file
#define FILE_ADD_SUBDIRECTORY (0x0004)     // directory
#define FILE_CREATE_PIPE_INSTANCE (0x0004) // named pipe


#define FILE_READ_EA (0x0008) // file & directory

#define FILE_WRITE_EA (0x0010) // file & directory

#define FILE_EXECUTE (0x0020)  // file
#define FILE_TRAVERSE (0x0020) // directory

#define FILE_DELETE_CHILD (0x0040) // directory

#define FILE_READ_ATTRIBUTES (0x0080) // all

#define FILE_WRITE_ATTRIBUTES (0x0100) // all

#define DELETE (0x00010000L)
#define READ_CONTROL (0x00020000L)
#define WRITE_DAC (0x00040000L)
#define WRITE_OWNER (0x00080000L)
#define SYNCHRONIZE (0x00100000L)

#define STANDARD_RIGHTS_REQUIRED (0x000F0000L)
#define STANDARD_RIGHTS_READ (0x00020000L)
#define STANDARD_RIGHTS_WRITE (0x00020000L)
#define STANDARD_RIGHTS_EXECUTE (0x00020000L)
#define STANDARD_RIGHTS_ALL (0x001F0000L)
#define SPECIFIC_RIGHTS_ALL (0x0000FFFFL)
#define ACCESS_SYSTEM_SECURITY (0x01000000L)
#define MAXIMUM_ALLOWED (0x02000000L)

#define FILE_CASE_SENSITIVE_SEARCH 0x00000001
#define FILE_CASE_PRESERVED_NAMES 0x00000002
#define FILE_UNICODE_ON_DISK 0x00000004

#define FILE_DEVICE_DISK 0x00000007


#define GENERIC_READ (0x80000000L)
#define GENERIC_WRITE (0x40000000L)
#define GENERIC_EXECUTE (0x20000000L)
#define GENERIC_ALL (0x10000000L)


#define FILE_SHARE_READ 0x00000001
#define FILE_SHARE_WRITE 0x00000002
#define FILE_SHARE_DELETE 0x00000004


#define FILE_ATTRIBUTE_READONLY 0x00000001
#define FILE_ATTRIBUTE_HIDDEN 0x00000002
#define FILE_ATTRIBUTE_SYSTEM 0x00000004
#define FILE_ATTRIBUTE_DIRECTORY 0x00000010
#define FILE_ATTRIBUTE_ARCHIVE 0x00000020
#define FILE_ATTRIBUTE_DEVICE 0x00000040
#define FILE_ATTRIBUTE_NORMAL 0x00000080
#define FILE_ATTRIBUTE_TEMPORARY 0x00000100
#define FILE_ATTRIBUTE_SPARSE_FILE 0x00000200
#define FILE_ATTRIBUTE_REPARSE_POINT 0x00000400
#define FILE_ATTRIBUTE_COMPRESSED 0x00000800
#define FILE_ATTRIBUTE_OFFLINE 0x00001000
#define FILE_ATTRIBUTE_NOT_CONTENT_INDEXED 0x00002000
#define FILE_ATTRIBUTE_ENCRYPTED 0x00004000
#define FILE_ATTRIBUTE_VIRTUAL 0x00010000


#define FILE_NOTIFY_CHANGE_FILE_NAME 0x00000001
#define FILE_NOTIFY_CHANGE_DIR_NAME 0x00000002
#define FILE_NOTIFY_CHANGE_NAME 0x00000003
#define FILE_NOTIFY_CHANGE_ATTRIBUTES 0x00000004
#define FILE_NOTIFY_CHANGE_SIZE 0x00000008
#define FILE_NOTIFY_CHANGE_LAST_WRITE 0x00000010
#define FILE_NOTIFY_CHANGE_LAST_ACCESS 0x00000020
#define FILE_NOTIFY_CHANGE_CREATION 0x00000040
#define FILE_NOTIFY_CHANGE_EA 0x00000080
#define FILE_NOTIFY_CHANGE_SECURITY 0x00000100
#define FILE_NOTIFY_CHANGE_STREAM_NAME 0x00000200
#define FILE_NOTIFY_CHANGE_STREAM_SIZE 0x00000400
#define FILE_NOTIFY_CHANGE_STREAM_WRITE 0x00000800
