// DVCPingClient.cpp : Implementation of CDVCPingClient

#include "pch.h"
#include "..\DVCPing\stdafx.h"
#include "framework.h"
#include "DVCPingVChan.h"


void
_MsgBox(const char *funcName, const char *fmt, ...)
{
   char buffer[1024];
   char *buf = buffer;
   int bufLen = ARRAYSIZE(buffer);

   int n = _snprintf_s(buf, bufLen, _TRUNCATE, "%s(): ", funcName);
   buf += n;
   bufLen -= n;

   va_list args;
   va_start(args, fmt);
   vsnprintf_s(buf, bufLen, _TRUNCATE, fmt, args);
   va_end(args);

   ::MessageBoxA(NULL, buffer, "DVCPingClient", MB_OK);
}


/*
 *----------------------------------------------------------------------
 *
 * CDVCPingClient::Initialize
 *
 *----------------------------------------------------------------------
 */
HRESULT STDMETHODCALLTYPE
CDVCPingClient::Initialize(IWTSVirtualChannelManager *pChannelMgr)
{
   HRESULT hr = CreateListener(pChannelMgr);
   CHECK_QUIT_HR("CreateListener(Short)");

   MsgBoxDbg("Initialize");
   return S_OK;
}


/*
 *----------------------------------------------------------------------
 *
 * CDVCPingClient::CreateListener
 *
 *----------------------------------------------------------------------
 */
HRESULT STDMETHODCALLTYPE
CDVCPingClient::CreateListener(IWTSVirtualChannelManager *pChannelMgr)
{
   // Create an instance of the CDVCPingListenerCallback object.
   CComObject<CDVCPingListenerCallback> *pListenerCallback;
   CComPtr<CDVCPingListenerCallback> ptrListenerCallback;

   HRESULT hr = CComObject<CDVCPingListenerCallback>::CreateInstance(&pListenerCallback);
   CHECK_QUIT_HR("CDVCPingListenerCallback::CreateInstance");
   ptrListenerCallback = pListenerCallback;

   // Attach the callback to the "DVC_Sample" endpoint.
   CComPtr<IWTSListener> ptrListener;
   hr = pChannelMgr->CreateListener(DVC_PING_CHANNEL_NAME, 0,
                                    (CDVCPingListenerCallback *)ptrListenerCallback, &ptrListener);
   CHECK_QUIT_HR("CreateListener");
   return S_OK;
}


/*
 *----------------------------------------------------------------------
 *
 * CDVCPingClient::Connected
 *
 *----------------------------------------------------------------------
 */
HRESULT STDMETHODCALLTYPE
CDVCPingClient::Connected()
{
   MsgBoxDbg("Connected");
   return S_OK;
}


/*
 *----------------------------------------------------------------------
 *
 * CDVCPingClient::Disconnected
 *
 *----------------------------------------------------------------------
 */
HRESULT STDMETHODCALLTYPE
CDVCPingClient::Disconnected(DWORD dwDisconnectCode)
{
   MsgBoxDbg("Disconnected");
   return S_OK;
}


/*
 *----------------------------------------------------------------------
 *
 * CDVCPingClient::Terminated
 *
 *----------------------------------------------------------------------
 */
HRESULT STDMETHODCALLTYPE
CDVCPingClient::Terminated()
{
   MsgBoxDbg("Terminated");
   return S_OK;
}


/*
 *----------------------------------------------------------------------
 *
 * CDVCPingListenerCallback::OnNewChannelConnection
 *
 *----------------------------------------------------------------------
 */
HRESULT
CDVCPingListenerCallback::OnNewChannelConnection(IWTSVirtualChannel *pChannel, BSTR data,
                                                 BOOL *pbAccept,
                                                 IWTSVirtualChannelCallback **ppCallback)
{
   MsgBoxDbg("Opening channel 0x%p", pChannel);
   HRESULT hr = S_OK;
   *pbAccept = FALSE;

   CComObject<CDVCPingChannelCallback> *pCallback;
   CComPtr<CDVCPingChannelCallback> ptrCallback;

   hr = CComObject<CDVCPingChannelCallback>::CreateInstance(&pCallback);
   CHECK_QUIT_HR("CDVCPingChannelCallback::CreateInstance");
   ptrCallback = pCallback;

   ptrCallback->SetChannel(pChannel);

   *ppCallback = ptrCallback;
   (*ppCallback)->AddRef();

   *pbAccept = TRUE;
   return hr;
}


/*
 *----------------------------------------------------------------------
 *
 * CDVCPingChannelCallback::SetChannel
 *
 *----------------------------------------------------------------------
 */
void
CDVCPingChannelCallback::SetChannel(IWTSVirtualChannel *pChannel)
{
   m_ptrChannel = pChannel;
}


/*
 *----------------------------------------------------------------------
 *
 * CDVCPingChannelCallback::OnDataReceived
 *
 *----------------------------------------------------------------------
 */
HRESULT STDMETHODCALLTYPE
CDVCPingChannelCallback::OnDataReceived(ULONG cbSize, BYTE *pBuffer)
{
   MsgBoxDbg("Channel 0x%p received \"%s\", %d bytes", m_ptrChannel.p, pBuffer, cbSize);
   return m_ptrChannel->Write(cbSize, pBuffer, NULL);
}


/*
 *----------------------------------------------------------------------
 *
 * CDVCPingChannelCallback::OnClose
 *
 *----------------------------------------------------------------------
 */
HRESULT STDMETHODCALLTYPE
CDVCPingChannelCallback::OnClose()
{
   MsgBoxDbg("Channel 0x%p closed", m_ptrChannel.p);
   return S_OK;
}
