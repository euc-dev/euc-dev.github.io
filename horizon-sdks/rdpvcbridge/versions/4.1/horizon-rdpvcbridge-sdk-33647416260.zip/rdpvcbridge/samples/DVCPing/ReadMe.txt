/*
 * Copyright (c) Omnissa, LLC. All rights reserved.
 * This product is protected by copyright and intellectual property laws in the
 * United States and other countries as well as by international treaties.
 * -- Omnissa Restricted
 */

/* **************************************************************************
 * NOTE: Within this document, file paths, registry keys, and similar code
 * related items are revised to reflect the SDK's use with the Omnissa stack
 * References to items that were for Horizon versions 8.13/2406 and earlier
 * contain asterisks (V**** or V**) to redact the previous name.
 * **************************************************************************/

DVCPing - uses dynamic virtual channels to send a ping
-----------------------------------------------------------------------

DVCPing has two components - client side (which is loaded by the
Horizon Client) and server side (which runs on the remote desktop).

1) Client side (Windows only)
  a) load DVCPing.sln and build DVCPingClient.  It must be built
     as a 64-bit binary to match the bit-level of the Horizon client.

  b) Copy the file, DVCPingClient.dll, to the client

  c) Open a command window and CD to the folder where you placed the DLL

  d) Register the virtual channel using one of two methods

     i) Method 1.d.i does not require the DLL to be registered as a COM object
        a) Add these registry settings
           [HKEY_CURRENT_USER\SOFTWARE\Microsoft\Terminal Server Client\Default\AddIns\DVCPing]
           "Name"="<MYFOLDER>\DVCPingClient.dll:{3A34B308-719B-4B61-A457-BB3F9F5DEB4E}"
           "Horizon Enabled"=dword:00000001

     ii) Method 1.d.ii requires the DLL to be registered as a COM object
        a) Add these registry settings
           [HKEY_CURRENT_USER\SOFTWARE\Microsoft\Terminal Server Client\Default\AddIns\DVCPing]
           "Name"="{3A34B308-719B-4B61-A457-BB3F9F5DEB4E}"
           "Horizon Enabled"=dword:00000001

        b) Run this command "As Administrator"
           C:> regsvr32 <MYFOLDER>\DVCPingClient.dll

        If running on Horizon v8.13 or earlier use the registry key
        "View Enabled" instead of "Horizon Enabled" when registering the DLL.


2) Server side (Windows only)
  a) load DVCPing.sln and build DVCPing.  It can be built as either a
     64-bit or 32-bit binary.

  b) Copy the file, DVCPing.exe, to the remote desktop

  c) If the Virtual Channel Security feature is enabled you will need to
     apply DVCPing.reg.  This is just a template file, you must modify
     the file to include the full path to DVCPing.exe before applying it.


3) Using the Horizon client, start a session to the remote desktop


4) Run the DVCPing.exe file from the remote desktop.
   Here is the sample output:
      wmain(74): Current process ID: 3828 / 0xef4 / x64 / Blast
      wmain(88): WTSVirtualChannelOpenEx(DVCPing) [OK] -> 0x0EF4000200000007
      wmain(116): String sent (Hello World):12
      wmain(142): Strings match(Hello World):12
      wmain(152): WTSVirtualChannelClose(0x0EF4000200000007) [OK]
      wmain(156): DVCPing complete      
