// DVCPing.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

#define MAP_RDPVCBRIDGE
#include "vdp_rdpvcbridge.h"

/*
 * Send log messages to the console as well as the rdpvcbridge logs
 */
#define GEN_LOG_MSG(...)                                                                           \
   char msg[1024];                                                                                 \
   int n = 0;                                                                                      \
                                                                                                   \
   n += _snprintf_s(msg + n, ARRAYSIZE(msg) - n, _TRUNCATE, "%s(%d): ", __FUNCTION__, __LINE__);   \
                                                                                                   \
   n += _snprintf_s(msg + n, ARRAYSIZE(msg) - n, _TRUNCATE, __VA_ARGS__);

#define LOG_DEBUG(...)                                                                             \
   do {                                                                                            \
      GEN_LOG_MSG(__VA_ARGS__);                                                                    \
      VDP_LOG_DEBUG("%s", msg);                                                                    \
   } while (false)

#define LOG_INFO(...)                                                                              \
   do {                                                                                            \
      GEN_LOG_MSG(__VA_ARGS__);                                                                    \
      VDP_LOG_INFO("%s", msg);                                                                     \
      fprintf(stdout, "%s\n", msg);                                                                \
   } while (false)

#define LOG_ERROR(...)                                                                             \
   do {                                                                                            \
      GEN_LOG_MSG(__VA_ARGS__);                                                                    \
      VDP_LOG_ERROR("%s", msg);                                                                    \
      fprintf(stderr, "%s\n", msg);                                                                \
   } while (false)


/*
 *----------------------------------------------------------------------
 *
 * _tmain
 *
 *----------------------------------------------------------------------
 */
int
_tmain(int argc, _TCHAR *argv[])
{
   HANDLE hVChan;
   char msgIn[1024];
   char msgOutBuffer[1024];
   char *msgOut = msgOutBuffer;
   ULONG nBytesIn;
   ULONG nBytesOut;

   /*
    * Log the information about the process and protocol
    */
#ifdef _WIN64
   const char *bitLevel = "x64";
#else
   const char *bitLevel = "x86";
#endif

   const char *protocol = VDP_IsBlastSession(WTS_CURRENT_SESSION)   ? "Blast"
                          : VDP_IsPCoIPSession(WTS_CURRENT_SESSION) ? "PCoIP"
                          : VDP_IsRDPSession(WTS_CURRENT_SESSION)   ? "RDP"
                                                                    : "Console";

   DWORD pid = ::GetCurrentProcessId();
   LOG_INFO("Current process ID: %d / 0x%x / %s / %s", pid, pid, bitLevel, protocol);

   /*
    * Open the channel
    */
   hVChan = WTSVirtualChannelOpenEx(WTS_CURRENT_SESSION, (LPSTR)DVC_PING_CHANNEL_NAME,
                                    WTS_CHANNEL_OPTION_DYNAMIC);
   if (hVChan == NULL) {
      LOG_ERROR("WTSVirtualChannelOpenEx(%s) failed (%d)", DVC_PING_CHANNEL_NAME, GetLastError());
      goto exit;
   }
   LOG_INFO("WTSVirtualChannelOpenEx(%s) [OK] -> 0x%p", DVC_PING_CHANNEL_NAME, hVChan);


   /*
    * Generate a "Hello" message
    */
   if (argc <= 1) {
      strcpy_s(msgIn, "Hello World");
      nBytesIn = (ULONG)strlen(msgIn) + 1;
   } else {
      nBytesIn = _snprintf_s(msgIn, ARRAYSIZE(msgIn), _TRUNCATE, "Hello %ls", argv[1]) + 1;
   }

   /*
    * Write the message.  The client side plugin will bounce it back.
    */
   if (!WTSVirtualChannelWrite(hVChan, (PCHAR)msgIn, nBytesIn, &nBytesOut)) {
      LOG_ERROR("WTSVirtualChannelWrite() failed (%d)", GetLastError());
      goto exit;
   }

   if (nBytesIn != nBytesOut) {
      LOG_ERROR("WTSVirtualChannelWrite() (%s):%d only wrote %d bytes", msgIn, nBytesIn, nBytesOut);
      goto exit;
   }

   LOG_INFO("String sent (%s):%d", msgIn, nBytesIn);


   /*
    * Read the response
    */
   if (!WTSVirtualChannelRead(hVChan, INFINITE, (PCHAR)msgOut, sizeof(msgOutBuffer), &nBytesOut)) {
      LOG_ERROR("WTSVirtualChannelRead() failed (%d)", GetLastError());
      goto exit;
   }

   /*
    * Ignore the CHANNEL_PDU_HEADER
    */
   msgOut += sizeof(CHANNEL_PDU_HEADER);
   nBytesOut -= sizeof(CHANNEL_PDU_HEADER);

   /*
    * Verify the number of bytes and string match
    */
   if (nBytesIn != nBytesOut || strcmp(msgIn, msgOut) != 0) {
      LOG_ERROR("String mismatch: sent(%s):%d  rcvd(%s):%d", msgIn, nBytesIn, msgOut, nBytesOut);
      goto exit;
   }

   LOG_INFO("Strings match(%s):%d", msgOut, nBytesOut);

exit:
   /*
    * Close the channel
    */
   if (hVChan != NULL) {
      if (!WTSVirtualChannelClose(hVChan)) {
         LOG_ERROR("WTSVirtualChannelClose(0x%p) failed (%d)", hVChan, GetLastError());
      } else {
         LOG_INFO("WTSVirtualChannelClose(0x%p) [OK]", hVChan);
      }
   }

   LOG_INFO("%s complete", DVC_PING_CHANNEL_NAME);
   return 0;
}
