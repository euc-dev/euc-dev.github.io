// dllmain.h : Declaration of module class.

class CDVCPingClientModule : public ATL::CAtlDllModuleT<CDVCPingClientModule> {
public:
   DECLARE_LIBID(LIBID_DVCPingClientLib)
   DECLARE_REGISTRY_APPID_RESOURCEID(IDR_DVCPINGCLIENT, "{9f97519f-7189-4dea-bf75-7d623ddc2fe7}")
};

extern class CDVCPingClientModule _AtlModule;
