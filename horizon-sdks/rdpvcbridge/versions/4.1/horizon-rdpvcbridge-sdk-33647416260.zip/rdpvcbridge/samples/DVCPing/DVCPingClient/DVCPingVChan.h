// DVCPingVChan.h : Declaration of the CDVCPingClient

#pragma once
#include "Resource.h" // main symbols
#include "DVCPingClient_i.h"


#define MsgBoxDbg(...) // MsgBox(__VA_ARGS__)
#define MsgBox(...) _MsgBox(__FUNCTION__, __VA_ARGS__)
void _MsgBox(const char *funcName, const char *fmt, ...);

#define CHECK_QUIT_HR(_x_)                                                                         \
   if (FAILED(hr)) {                                                                               \
      MsgBox("FAILED: " _x_);                                                                      \
      return hr;                                                                                   \
   }


/*
 *----------------------------------------------------------------------
 *
 * Class CDVCPingClient
 *
 *    Implements IWTSPlugin
 *
 *----------------------------------------------------------------------
 */
class ATL_NO_VTABLE CDVCPingClient :
   public CComObjectRootEx<CComMultiThreadModel>,
   public CComCoClass<CDVCPingClient, &CLSID_DVCPingClient>,
   public IDVCPingClient {
public:
   DECLARE_REGISTRY_RESOURCEID(IDR_DVCPINGCLIENT)

   BEGIN_COM_MAP(CDVCPingClient)
   COM_INTERFACE_ENTRY(IDVCPingClient)
   COM_INTERFACE_ENTRY(IWTSPlugin)
   END_COM_MAP()

   DECLARE_PROTECT_FINAL_CONSTRUCT()
   HRESULT FinalConstruct() { return S_OK; }
   void FinalRelease() {}

private:
   HRESULT STDMETHODCALLTYPE Initialize(IWTSVirtualChannelManager *pChannelMgr);
   HRESULT STDMETHODCALLTYPE Connected();
   HRESULT STDMETHODCALLTYPE Disconnected(DWORD dwDisconnectCode);
   HRESULT STDMETHODCALLTYPE Terminated();

   HRESULT STDMETHODCALLTYPE CreateListener(IWTSVirtualChannelManager *pChannelMgr);
};

OBJECT_ENTRY_AUTO(__uuidof(DVCPingClient), CDVCPingClient)


/*
 *----------------------------------------------------------------------
 *
 * Class CDVCPingListenerCallback
 *
 *    Implements IWTSListenerCallback
 *
 *----------------------------------------------------------------------
 */
class ATL_NO_VTABLE CDVCPingListenerCallback :
   public CComObjectRootEx<CComMultiThreadModel>,
   public CComCoClass<CDVCPingListenerCallback, &CLSID_DVCPingListenerCallback>,
   public IDVCPingListenerCallback {
public:
   DECLARE_REGISTRY_RESOURCEID(IDR_DVCPINGLISTENERCALLBACK)

   BEGIN_COM_MAP(CDVCPingListenerCallback)
   COM_INTERFACE_ENTRY(IDVCPingListenerCallback)
   END_COM_MAP()

   DECLARE_PROTECT_FINAL_CONSTRUCT()
   HRESULT FinalConstruct() { return S_OK; }
   void FinalRelease() { MsgBoxDbg(""); }

private:
   HRESULT STDMETHODCALLTYPE OnNewChannelConnection(__in IWTSVirtualChannel *pChannel,
                                                    __in_opt BSTR data, __out BOOL *pbAccept,
                                                    __out IWTSVirtualChannelCallback **ppCallback);
};

OBJECT_ENTRY_AUTO(__uuidof(DVCPingListenerCallback), CDVCPingListenerCallback)


/*
 *----------------------------------------------------------------------
 *
 * Class CDVCPingChannelCallback
 *
 *    Implements IWTSVirtualChannelCallback
 *
 *----------------------------------------------------------------------
 */
class ATL_NO_VTABLE CDVCPingChannelCallback :
   public CComObjectRootEx<CComMultiThreadModel>,
   public CComCoClass<CDVCPingChannelCallback, &CLSID_DVCPingChannelCallback>,
   public IDVCPingChannelCallback {
public:
   DECLARE_REGISTRY_RESOURCEID(IDR_DVCPINGCHANNELCALLBACK)

   BEGIN_COM_MAP(CDVCPingChannelCallback)
   COM_INTERFACE_ENTRY(IDVCPingChannelCallback)
   END_COM_MAP()

   DECLARE_PROTECT_FINAL_CONSTRUCT()
   HRESULT FinalConstruct() { return S_OK; }
   void FinalRelease() { MsgBoxDbg(""); }

   void SetChannel(IWTSVirtualChannel *pChannel);

private:
   HRESULT STDMETHODCALLTYPE OnDataReceived(ULONG cbSize, BYTE *pBuffer);
   HRESULT STDMETHODCALLTYPE OnClose();

   CComPtr<IWTSVirtualChannel> m_ptrChannel;
};

OBJECT_ENTRY_AUTO(__uuidof(DVCPingChannelCallback), CDVCPingChannelCallback)
