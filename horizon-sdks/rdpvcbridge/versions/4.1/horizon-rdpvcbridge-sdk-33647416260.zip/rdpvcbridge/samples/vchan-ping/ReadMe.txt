/*
 * Copyright (c) Omnissa, LLC. All rights reserved.
 * This product is protected by copyright and intellectual property laws in the
 * United States and other countries as well as by international treaties.
 * -- Omnissa Restricted
 */

/* **************************************************************************
 * NOTE: Within this document, file paths, registry keys, and similar code
 * related items are revised to reflect the SDK's use with the Omnissa stack
 * References to items that were for Horizon versions 8.13/2406 and earlier
 * contain asterisks (V**** or V**) to redact the previous name.
 * **************************************************************************/

vchan-ping - uses static virtual channels to send a ping
-----------------------------------------------------------------------

vchan-ping has two components - client side (which is loaded by the
Horizon Client) and server side (which runs on the remote desktop).

1) Client side (Windows)
  a) load vchan-ping.sln and build vchan-ping-client.dll.  It must be
     built as a 64-bit binary to match the bit-level of the Horizon client.

  b) Copy the file, vchan-ping-client.dll, to the client

  c) Open a command window and CD to the folder where you placed the DLL

  d) Register the DLL using regsvr32.exe (which comes with Windows)

  e) Run this command "As Administrator"
     C:> regsvr32 vchan-ping-client.dll

  f) It can be unregistered by passing /u option
     C:> regsvr32 /u vchan-ping-client.dll


2) Client side (Linux)
  a) There is a Makefile in the vchan-ping-client folder which will build
     libvchanpingclient.so.  The Makefile will also detect if the Horizon
     client is installed on the system, and if so, automatically copy the
     binary to the correct folder.

  b) If not already done so by the Makefile, copy libvchanpingclient.so
     to ~/.omnissa/rdpvcbridge or /lib/.omnissa/rdpvcbridge

     If running on Horizon v8.13 or earlier you must copy
     libvchanpingclient.so to one of the legacy plugin folders;
     ~/.v*****/rdpvcbridge or /lib/.v*****/rdpvcbridge


3) Client side (Mac)
  a) There is a Makefile in the vchan-ping-client folder which will build
     libvchanpingclient.dylib.  The Makefile will also detect if the Horizon
     client is installed on the system, and if so, automatically copy the
     binary to the correct folder.

  b) libvchanpingclient.dylib must be signed with the developer's Apple ID
     certificate unless SIP is disabled.

  c) If not already done so by the Makefile, copy libvchanpingclient.dylib
     to ~/.omnissa/rdpvcbridge or /Library/.omnissa/rdpvcbridge

     If running on Horizon v8.13 or earlier you must copy libvchanpingclient.dylib
     to one of the legacy plugin folders; ~/.v*****/rdpvcbridge or
     /Library/.v*****/rdpvcbridge


4) Server side (Windows only)
  a) load vchan-ping.sln and build vchan-ping.  It can be built as either a
     64-bit or 32-bit binary.

  b) Copy the file, vchan-ping.exe, to the remote desktop

  c) If the Virtual Channel Security feature is enabled you will need to
     apply vchan-ping.reg.  This is just a template file, you must modify
     the file to include the full path to vchan-ping.exe before applying
     it.


5) Using the Horizon client, start a session to the remote desktop


6) Run the vchan-ping.exe file from the remote desktop.
   Here is the sample output:
      Omnissa Horizon installed
      Local SDK version: v8 - v8.18.0 build-22787054278 e481028c53d (Mar  6 2026 16:22:00)
      Remote SDK version: v8 - v8.18.0 build-22787047440 e481028c53d (Mar  6 2026 16:16:32)
      Session Activity ID: d0212eda-6dd9-44f3-971f-d290e2c3e28c
      Current protocol is BLAST (Horizon session)
      clayton connected from ClaytonWin11-1 (Windows)
      Current session is in DESKTOP mode
      The remote-side client is not in a nested session
      4 pings sent (avg=0.2ms)
