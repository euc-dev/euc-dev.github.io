/*
 * Copyright (c) Omnissa, LLC. All rights reserved.
 * This product is protected by copyright and intellectual property laws in the
 * United States and other countries as well as by international treaties.
 * -- Omnissa Restricted
 */

/*
 * vchan-ping.cpp
 *
 *    This is the server side of a simple virtual channel application.
 *    The application sends a message to the client side, which then
 *    sends back a response.
 */

#include "stdafx.h"
#include "vchan-ping-defs.h"

/*
 * Global variables
 */
HANDLE g_hVChan = NULL;


/*
 * Fill in whatever logging mechanism you want to use
 */
#define LOG_MESSAGE(...)                                                                           \
   do {                                                                                            \
      printf(__VA_ARGS__);                                                                         \
      VDP_LOG_INFO(__VA_ARGS__);                                                                   \
   } while (false)

#define LOG_ERROR(...)                                                                             \
   do {                                                                                            \
      printf(__VA_ARGS__);                                                                         \
      VDP_LOG_ERROR(__VA_ARGS__);                                                                  \
   } while (false)


/*
 *----------------------------------------------------------------------
 *
 * Function GetCurrentProtocol
 *
 *    Gets & prints the current remote protocol
 *
 * Results:
 *    None.
 *
 * Side effects:
 *    None.
 *
 *----------------------------------------------------------------------
 */
void
GetCurrentProtocol()
{
   BOOL isHorizon = VDP_IsHorizonSession(WTS_CURRENT_SESSION);
   const char *isHorizonStr = isHorizon ? " (Horizon session)" : " (Not a Horizon session)";

   LPTSTR pBuffer = NULL;
   DWORD bytesReturned = 0;
   if (!WTSQuerySessionInformation(WTS_CURRENT_SERVER_HANDLE, WTS_CURRENT_SESSION,
                                   WTSClientProtocolType, &pBuffer, &bytesReturned)) {
      return;
   }

   USHORT wtsProtocol = *(USHORT *)pBuffer;
   WTSFreeMemory(pBuffer);

   switch (wtsProtocol) {
   case WTS_PROTOCOL_TYPE_CONSOLE:
      LOG_MESSAGE("Current protocol is CONSOLE%s\n", isHorizonStr);
      break;

   case WTS_PROTOCOL_TYPE_RDP:
      LOG_MESSAGE("Current protocol is RDP%s\n", isHorizonStr);
      break;

   case WTS_PROTOCOL_TYPE_PCOIP:
      LOG_MESSAGE("Current protocol is PCOIP%s\n", isHorizonStr);
      break;

   case WTS_PROTOCOL_TYPE_BLAST:
      LOG_MESSAGE("Current protocol is BLAST%s\n", isHorizonStr);
      break;

   default:
      LOG_MESSAGE("Unknown protocol %d%s\n", wtsProtocol, isHorizonStr);
      break;
   }
}


/*
 *----------------------------------------------------------------------
 *
 * Function GetUserInformation
 *
 *    Gets & prints information about the current user
 *
 * Results:
 *    None.
 *
 * Side effects:
 *    None.
 *
 *----------------------------------------------------------------------
 */
void
GetUserInformation()
{
   LPTSTR pBuffer = NULL;
   DWORD bytesReturned = 0;

   std::string userName = "UnknownUser";
   if (WTSQuerySessionInformation(WTS_CURRENT_SERVER_HANDLE, WTS_CURRENT_SESSION, WTSUserName,
                                  &pBuffer, &bytesReturned)) {
      userName = (const char *)pBuffer;
      WTSFreeMemory(pBuffer);
   }

   std::string clientName = "UnknownClient";
   if (WTSQuerySessionInformation(WTS_CURRENT_SERVER_HANDLE, WTS_CURRENT_SESSION, WTSClientName,
                                  &pBuffer, &bytesReturned)) {
      clientName = (const char *)pBuffer;
      WTSFreeMemory(pBuffer);
   }

   char clientOSType[64];
   if (!VDP_GetClientOSType(WTS_CURRENT_SESSION, clientOSType, ARRAYSIZE(clientOSType))) {
      strcpy_s(clientOSType, ARRAYSIZE(clientOSType), "UnknownOSType");
   }

   LOG_MESSAGE("%s connected from %s (%s)\n", userName.c_str(), clientName.c_str(), clientOSType);
}


/*
 *----------------------------------------------------------------------
 *
 * Function GetSessionActivityId
 *
 *    Gets & prints Horizon's the Session Activity ID.
 *    This is a GUID that uniquely identifies the Horizon session.
 *
 * Results:
 *    None.
 *
 * Side effects:
 *    None.
 *
 *----------------------------------------------------------------------
 */
void
GetSessionActivityId()
{
   ULONG sessionActivityIdSz = 0;
   VDP_GetSessionActivityID(WTS_CURRENT_SESSION, NULL, &sessionActivityIdSz);

   std::vector<char> sessionActivityId(sessionActivityIdSz, '\0');
   VDP_GetSessionActivityID(WTS_CURRENT_SESSION, sessionActivityId.data(), &sessionActivityIdSz);

   LOG_MESSAGE("Session Activity ID: %s\n", sessionActivityId.data());
}


/*
 *----------------------------------------------------------------------
 *
 * Function GetSDKVersion
 *
 *    Gets & prints the version of the RDPVCBridge SDK running locally as
 *    well as at the remote end
 *
 * Results:
 *    None.
 *
 * Side effects:
 *    None.
 *
 *----------------------------------------------------------------------
 */
void
GetSDKVersion()
{
   char localVersionStr[1024];
   ULONG localVersionStrLen = ARRAYSIZE(localVersionStr);
   ULONG localResultStrSize = 0;
   ULONG localVersionNum = 0;

   char remoteVersionStr[1024];
   ULONG remoteVersionStrLen = ARRAYSIZE(remoteVersionStr);
   ULONG remoteResultStrSize = 0;
   ULONG remoteVersionNum = 0;

   /*
    * The function will only fail if we pass it invalid parameters
    */
   if (!VDP_GetSDKVersion(WTS_CURRENT_SESSION, localVersionStr, localVersionStrLen,
                          &localResultStrSize, &localVersionNum, remoteVersionStr,
                          remoteVersionStrLen, &remoteResultStrSize, &remoteVersionNum)) {
      LOG_MESSAGE("VDP_GetSDKVersion() failed\n");
      return;
   }

   /*
    * The local version is always returned
    */
   LOG_MESSAGE("Local SDK version: v%d - v%s\n", localVersionNum, localVersionStr);

   /*
    * The remote version is only returned if we can detect the client side rdpvcbridge DLL.
    * Two common reason reasons for remoteVersionNum == 0 are 1) there isn't a connection
    * in place, and 2) we are connected with RDP which doesn't use rdpvcbridge.
    */
   if (remoteVersionNum != 0) {
      LOG_MESSAGE("Remote SDK version: v%d - v%s\n", remoteVersionNum, remoteVersionStr);
   }
}


/*
 *----------------------------------------------------------------------
 *
 * Function CheckSessionMode
 *
 *    Determine if we are in a DESKTOP or APPLICATION session.
 *
 * Results:
 *    None.
 *
 * Side effects:
 *    None.
 *
 *----------------------------------------------------------------------
 */
void
CheckSessionMode()
{
   if (VDP_IsDesktopSession(WTS_CURRENT_SESSION)) {
      LOG_MESSAGE("Current session is in DESKTOP mode\n");
   }
   if (VDP_IsApplicationSession(WTS_CURRENT_SESSION)) {
      LOG_MESSAGE("Current session is in APPLICATION mode\n");
   }
}


/*
 *----------------------------------------------------------------------
 *
 * Function CheckForNestedSession
 *
 *    Determine if we are in the nested session or not.
 *
 * Results:
 *    None.
 *
 * Side effects:
 *    None.
 *
 *----------------------------------------------------------------------
 */
void
CheckForNestedSession()
{
   BOOL isNested = false;
   VDP_IsNestedSession(WTS_CURRENT_SESSION, &isNested);
   LOG_MESSAGE("The remote-side client is%s in a nested session\n", (isNested ? "" : " not"));
}


/*
 *----------------------------------------------------------------------
 *
 * Function Init
 *
 * Results:
 *    Returns true if sucessful
 *
 * Side effects:
 *    The virtual channel is opened and the global g_hVChan is updated.
 *
 *----------------------------------------------------------------------
 */
bool
Init()
{
   g_hVChan = WTSVirtualChannelOpen(WTS_CURRENT_SERVER_HANDLE, WTS_CURRENT_SESSION, VCHAN_NAME);

   if (g_hVChan == NULL) {
      LOG_ERROR("Error opening virtual channel\n");
      return false;
   }

   return true;
}


/*
 *----------------------------------------------------------------------
 *
 * Function Exit
 *
 * Results:
 *    None
 *
 * Side effects:
 *    The virtual channel is closed and the global g_hVChan is updated.
 *
 *----------------------------------------------------------------------
 */
void
Exit()
{
   if (g_hVChan != NULL) {
      WTSVirtualChannelClose(g_hVChan);
      g_hVChan = NULL;
   }
}


/*
 *----------------------------------------------------------------------
 *
 * Function Ping
 *
 * Results:
 *    None
 *
 * Side effects:
 *    None
 *
 *----------------------------------------------------------------------
 */
void
Ping(int pingCount)
{
   const char *msgSend = SERVER_MESSAGE;
   ULONG msgSendLen = (ULONG)::strlen(msgSend) + 1;

   char msgRecv[1024];
   ULONG msgRecvLen = sizeof(msgRecv);

   ULONG byteCount = 0;
   ULONG msTimeout = 1000;
   long reportInterval = 100;

   DWORD pingTimeTotal = 0;
   int pingTimeCount = 0;

   for (int iPing = 1; iPing <= pingCount; ++iPing) {
      DWORD pingTime = GetTickCount();

      if (!WTSVirtualChannelWrite(g_hVChan, (PCHAR)msgSend, msgSendLen, &byteCount)) {
         LOG_ERROR("Error writing virtual channel\n");
         break;
      }

      if (!WTSVirtualChannelRead(g_hVChan, msTimeout, msgRecv, msgRecvLen, &byteCount)) {
         LOG_ERROR("Error reading virtual channel\n");
         break;
      }

      pingTime = GetTickCount() - pingTime;
      pingTimeTotal += pingTime;
      pingTimeCount++;

      if (::strcmp(msgRecv, CLIENT_MESSAGE) != 0) {
         LOG_ERROR("Incorrect client response\n");
         break;
      }

      if (iPing % reportInterval == 0 || iPing == pingCount) {
         double pingTimeAvg = (double)pingTimeTotal / pingTimeCount;
         pingTimeTotal = 0;
         pingTimeCount = 0;

         LOG_MESSAGE("%d pings sent (avg=%3.1fms)\n", iPing, pingTimeAvg);
      }
   }
}


/*
 *----------------------------------------------------------------------
 *
 * Function _tmain
 *
 * Results:
 *    None
 *
 * Side effects:
 *    None
 *
 *----------------------------------------------------------------------
 */
int
_tmain(int argc, _TCHAR *argv[])
{
   int n = argc > 1 ? _ttoi(argv[1]) : 4;

   if (!VDP_IsRdpvcbridgeLoaded()) {
      LOG_ERROR("RDPVCBridge is not loaded\n");
      return 1;
   }

   if (VDP_IsOmnissaHorizonInstalled()) {
      LOG_MESSAGE("Omnissa Horizon installed\n");
   } else if (VDP_IsLegacyHorizonInstalled()) {
      LOG_MESSAGE("Legacy Horizon installed\n");
   }

   GetSDKVersion();
   GetSessionActivityId();
   GetCurrentProtocol();
   GetUserInformation();
   CheckSessionMode();
   CheckForNestedSession();

   if (Init()) {
      Ping(n);
      Exit();
   }

   LOG_MESSAGE("Press ENTER to exit\n");
   getchar();
   return 0;
}
