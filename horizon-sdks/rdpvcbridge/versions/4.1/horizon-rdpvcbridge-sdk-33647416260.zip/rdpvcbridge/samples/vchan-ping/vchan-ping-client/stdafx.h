/*
 * Copyright (c) Omnissa, LLC. All rights reserved.
 * This product is protected by copyright and intellectual property laws in the
 * United States and other countries as well as by international treaties.
 * -- Omnissa Restricted
 */

/*
 * stdafx.h
 */

#pragma once

#ifdef _WIN32

// Modify the following defines if you have to target a platform prior to the ones specified below.
// Refer to MSDN for the latest info on corresponding values for different platforms.
#   ifndef WINVER // Allow use of features specific to Windows XP or later.
#      define WINVER                                                                               \
         0x0501 // Change this to the appropriate value to target other versions of Windows.
#   endif

#   ifndef _WIN32_WINNT // Allow use of features specific to Windows XP or later.
#      define _WIN32_WINNT                                                                         \
         0x0501 // Change this to the appropriate value to target other versions of Windows.
#   endif

#   ifndef _WIN32_WINDOWS // Allow use of features specific to Windows 98 or later.
#      define _WIN32_WINDOWS                                                                       \
         0x0410 // Change this to the appropriate value to target Windows Me or later.
#   endif

#   ifndef _WIN32_IE // Allow use of features specific to IE 6.0 or later.
#      define _WIN32_IE                                                                            \
         0x0600 // Change this to the appropriate value to target other versions of IE.
#   endif

#   ifndef WIN32_LEAN_AND_MEAN
#      define WIN32_LEAN_AND_MEAN // Exclude rarely-used stuff from Windows headers
#   endif

#   include <windows.h>
#   include <tchar.h>
#endif


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <string>

/*
 * Required for all rdpvcbridge virtual channel plugins
 */
#if defined(_WIN32)
#   define VDP_RDPVCBRIDGE_API
#   include <cchannel.h>

#else
#   define VDP_RDPVCBRIDGE_API __attribute__((visibility("default")))

#   ifndef USE_WIN_DWORD_RANGE
#      define USE_WIN_DWORD_RANGE
#   endif

#   include "wintypes.h"
#   include "wts_api_lin.h"
#endif
