/*
 * Copyright (c) Omnissa, LLC. All rights reserved.
 * This product is protected by copyright and intellectual property laws in the
 * United States and other countries as well as by international treaties.
 * -- Omnissa Restricted
 */

/*
 * vdp_rdpvcbridge.h --
 */


#ifndef VDP_RDPVCBRIDGE_H
#define VDP_RDPVCBRIDGE_H

/*
 * VDP_RDPVCBRIDGE_API is applied to all the functions exported by the DLL.
 */
#if defined(_WIN32)
#   ifdef VDP_RDPVCBRIDGE_EXPORTS
// Export all the API functions when compiling the DLL
#      define VDP_RDPVCBRIDGE_API __declspec(dllexport)
#   else
// The import library is no longer provided as part of the SDK
// It has been replaced by vdp_rdpvcbridge_import.cpp
#      define VDP_RDPVCBRIDGE_API // __declspec(dllimport)
#   endif
#else
#   define VDP_RDPVCBRIDGE_API __attribute__((visibility("default")))
#endif


/*
 * Defining this symbol will map all the WTS Virtual Channel functions
 * to their VDP equivalents.
 */
#ifdef MAP_RDPVCBRIDGE

#   define WTSVirtualChannelOpen VDP_VirtualChannelOpen
#   define WTSVirtualChannelOpenEx VDP_VirtualChannelOpenEx
#   define WTSVirtualChannelClose VDP_VirtualChannelClose
#   define WTSVirtualChannelRead VDP_VirtualChannelRead
#   define WTSVirtualChannelWrite VDP_VirtualChannelWrite
#   define WTSVirtualChannelPurgeInput VDP_VirtualChannelPurgeInput
#   define WTSVirtualChannelPurgeOutput VDP_VirtualChannelPurgeOutput
#   define WTSVirtualChannelQuery VDP_VirtualChannelQuery
#   define WTSFreeMemory VDP_FreeMemory
#   define WTSRegisterSessionNotification VDP_RegisterSessionNotification
#   define WTSUnRegisterSessionNotification VDP_UnRegisterSessionNotification
#   define GetSystemMetrics VDP_GetSystemMetrics

#   ifdef UNICODE
#      undef WTSQuerySessionInformation
#      define WTSQuerySessionInformation VDP_QuerySessionInformationW
#      define VDP_QuerySessionInformation VDP_QuerySessionInformationW
#   else
#      undef WTSQuerySessionInformation
#      define WTSQuerySessionInformation VDP_QuerySessionInformationA
#      define VDP_QuerySessionInformation VDP_QuerySessionInformationA
#   endif

#endif // #ifdef MAP_RDPVCBRIDGE

/*
 * Compile out Server-side function prototypes for Linux.
 */
#if defined(_WIN32)


/*
 *----------------------------------------------------------------------
 *
 * Server side virtual channel API
 *
 *----------------------------------------------------------------------
 */

#   ifdef __cplusplus
extern "C" {
#   endif

/*
 * Horizon protocol types for QuerySessionInformation(WTSClientProtocolType)
 */
#   define WTS_PROTOCOL_TYPE_PCOIP 8
#   define WTS_PROTOCOL_TYPE_BLAST 9


/*
 * VDP_IsViewSession() was deprecated in v8.14
 */
#   define VDP_IsViewSession VDP_IsHorizonSession


/*
 * API function prototypes
 */
VDP_RDPVCBRIDGE_API BOOL VDP_IsRdpvcbridgeLoaded();

VDP_RDPVCBRIDGE_API BOOL VDP_IsLegacyHorizonInstalled();

VDP_RDPVCBRIDGE_API BOOL VDP_IsOmnissaHorizonInstalled();

VDP_RDPVCBRIDGE_API BOOL VDP_IsHorizonSession(DWORD sessionID);

VDP_RDPVCBRIDGE_API BOOL VDP_IsPCoIPSession(DWORD sessionID);

VDP_RDPVCBRIDGE_API BOOL VDP_IsBlastSession(DWORD sessionID);

VDP_RDPVCBRIDGE_API BOOL VDP_IsRDPSession(DWORD sessionID);

VDP_RDPVCBRIDGE_API BOOL VDP_IsDesktopSession(DWORD sessionID);

VDP_RDPVCBRIDGE_API BOOL VDP_IsApplicationSession(DWORD sessionID);

VDP_RDPVCBRIDGE_API BOOL VDP_AreVirtualChannelsAvailable(DWORD sessionID);

VDP_RDPVCBRIDGE_API BOOL VDP_IsNestedSession(const DWORD sessionID, BOOL *isNestedSession);

VDP_RDPVCBRIDGE_API BOOL VDP_IsNestedClient(const DWORD sessionID, BOOL *isNestedClient);

VDP_RDPVCBRIDGE_API BOOL VDP_SetClientPluginRetryInterval(DWORD msInterval);

VDP_RDPVCBRIDGE_API DWORD VDP_GetClientPluginRetryInterval();

VDP_RDPVCBRIDGE_API BOOL VDP_GetSDKVersion(const DWORD sessionID, PCHAR localVersionBuffer,
                                           const ULONG localVersionBufferSize,
                                           PULONG pLocalVersionResultStrSize,
                                           PULONG pLocalVersionNum, PCHAR remoteVersionBuffer,
                                           const ULONG remoteVersionBufferSize,
                                           PULONG pRemoteVersionResultStrSize,
                                           PULONG pRemoteVersionNum);

VDP_RDPVCBRIDGE_API HANDLE VDP_VirtualChannelOpen(HANDLE hServer, DWORD sessionID,
                                                  LPSTR pVirtualName);

VDP_RDPVCBRIDGE_API HANDLE VDP_VirtualChannelOpenEx(DWORD sessionID, LPSTR pVirtualName,
                                                    DWORD flags);

VDP_RDPVCBRIDGE_API BOOL VDP_VirtualChannelClose(HANDLE hChannel);

VDP_RDPVCBRIDGE_API BOOL VDP_VirtualChannelRead(HANDLE hChannel, ULONG timeout, PCHAR buffer,
                                                ULONG bufferSize, PULONG pBytesRead);

VDP_RDPVCBRIDGE_API BOOL VDP_VirtualChannelWrite(HANDLE hChannel, PCHAR buffer, ULONG length,
                                                 PULONG pBytesWritten);

VDP_RDPVCBRIDGE_API BOOL VDP_VirtualChannelPurgeInput(HANDLE hChannel);

VDP_RDPVCBRIDGE_API BOOL VDP_VirtualChannelPurgeOutput(HANDLE hChannel);

VDP_RDPVCBRIDGE_API BOOL VDP_VirtualChannelQuery(HANDLE hChannel, WTS_VIRTUAL_CLASS wtsVirtualClass,
                                                 PVOID *ppBuffer, DWORD *pBytesReturned);

VDP_RDPVCBRIDGE_API BOOL VDP_QuerySessionInformationA(HANDLE hServer, DWORD sessionID,
                                                      WTS_INFO_CLASS wtsInfoClass, LPSTR *ppBuffer,
                                                      DWORD *pBytesReturned);

VDP_RDPVCBRIDGE_API BOOL VDP_QuerySessionInformationW(HANDLE hServer, DWORD sessionID,
                                                      WTS_INFO_CLASS wtsInfoClass, LPWSTR *ppBuffer,
                                                      DWORD *pBytesReturned);

VDP_RDPVCBRIDGE_API void VDP_FreeMemory(PVOID pMemory);

VDP_RDPVCBRIDGE_API BOOL VDP_RegisterSessionNotification(HWND hWnd, DWORD dwFlags);

VDP_RDPVCBRIDGE_API BOOL VDP_UnRegisterSessionNotification(HWND hWnd);

VDP_RDPVCBRIDGE_API int VDP_GetSystemMetrics(int nIndex);


/*
 * Functions/macros to write a message into the rdpvcbridge log file
 */
VDP_RDPVCBRIDGE_API BOOL VDP_LogMessage(int logLevel, const char *funcName, const char *format,
                                        ...);

VDP_RDPVCBRIDGE_API BOOL VDP_LogvMessage(int logLevel, const char *funcName, const char *format,
                                         va_list args);

#   define VDP_LOG_ALWAYS(...) VDP_LogMessage(0, __FUNCTION__, __VA_ARGS__)
#   define VDP_LOG_ERROR(...) VDP_LogMessage(1, __FUNCTION__, __VA_ARGS__)
#   define VDP_LOG_WARN(...) VDP_LogMessage(2, __FUNCTION__, __VA_ARGS__)
#   define VDP_LOG_INFO(...) VDP_LogMessage(3, __FUNCTION__, __VA_ARGS__)
#   define VDP_LOG_DEBUG(...) VDP_LogMessage(4, __FUNCTION__, __VA_ARGS__)
#   define VDP_LOG_TRACE(...) VDP_LogMessage(5, __FUNCTION__, __VA_ARGS__)
#   define VDP_LOG_VERBOSE(...) VDP_LogMessage(6, __FUNCTION__, __VA_ARGS__)

#   define VDP_LOGV_ALWAYS(...) VDP_LogvMessage(0, __FUNCTION__, __VA_ARGS__)
#   define VDP_LOGV_ERROR(...) VDP_LogvMessage(1, __FUNCTION__, __VA_ARGS__)
#   define VDP_LOGV_WARN(...) VDP_LogvMessage(2, __FUNCTION__, __VA_ARGS__)
#   define VDP_LOGV_INFO(...) VDP_LogvMessage(3, __FUNCTION__, __VA_ARGS__)
#   define VDP_LOGV_DEBUG(...) VDP_LogvMessage(4, __FUNCTION__, __VA_ARGS__)
#   define VDP_LOGV_TRACE(...) VDP_LogvMessage(5, __FUNCTION__, __VA_ARGS__)
#   define VDP_LOGV_VERBOSE(...) VDP_LogvMessage(6, __FUNCTION__, __VA_ARGS__)

#   ifdef __cplusplus
}
#   endif

#endif // WIN32

#endif
