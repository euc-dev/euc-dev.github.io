#ifndef WTS_API_LIN_H
#define WTS_API_LIN_H

#define WTS_CURRENT_SESSION ((DWORD) - 1)

typedef HANDLE HINSTANCE;
typedef HINSTANCE HMODULE;

/*
 * Reference: http://msdn.microsoft.com/en-us/library/windows/desktop/aa383861(v=vs.85).aspx
 */

typedef enum _WTS_INFO_CLASS {
   WTSInitialProgram = 0,
   WTSApplicationName = 1,
   WTSWorkingDirectory = 2,
   WTSOEMId = 3,
   WTSSessionId = 4,
   WTSUserName = 5,
   WTSWinStationName = 6,
   WTSDomainName = 7,
   WTSConnectState = 8,
   WTSClientBuildNumber = 9,
   WTSClientName = 10,
   WTSClientDirectory = 11,
   WTSClientProductId = 12,
   WTSClientHardwareId = 13,
   WTSClientAddress = 14,
   WTSClientDisplay = 15,
   WTSClientProtocolType = 16,
   WTSIdleTime = 17,
   WTSLogonTime = 18,
   WTSIncomingBytes = 19,
   WTSOutgoingBytes = 20,
   WTSIncomingFrames = 21,
   WTSOutgoingFrames = 22,
   WTSClientInfo = 23,
   WTSSessionInfo = 24,
   WTSSessionInfoEx = 25,
   WTSConfigInfo = 26,
   WTSValidationInfo = 27,
   WTSSessionAddressV4 = 28,
   WTSIsRemoteSession = 29,
   // Fix warnings for some values defined in NetworkUtils.h which is from 1000 to 1004.
   WTSEnumMax = 1005,
} WTS_INFO_CLASS;

/*
 * Reference: http://msdn.microsoft.com/en-us/library/windows/desktop/aa383857(v=vs.85).aspx
 */

typedef struct _WTS_CLIENT_ADDRESS {
   DWORD AddressFamily;
   BYTE Address[20];
} WTS_CLIENT_ADDRESS, *PWTS_CLIENT_ADDRESS;

/*
 * Reference: http://msdn.microsoft.com/en-us/library/windows/desktop/aa383564(v=vs.85).aspx
 */

#define CHANNEL_NAME_LEN 7

typedef struct _CHANNEL_DEF {
   char name[CHANNEL_NAME_LEN + 1];
   ULONG options;
} CHANNEL_DEF, *PCHANNEL_DEF, **PPCHANNEL_DEF;

typedef VOID (*VirtualChannelInitEvent)(LPVOID pInitHandle, UINT event, LPVOID pData,
                                        UINT dataLength);

typedef VirtualChannelInitEvent PCHANNEL_INIT_EVENT_FN;

typedef UINT (*VirtualChannelInit)(LPVOID *ppInitHandle, PCHANNEL_DEF pChannel, INT channelCount,
                                   ULONG versionRequested,
                                   PCHANNEL_INIT_EVENT_FN pChannelInitEventProc);

typedef VirtualChannelInit PVIRTUALCHANNELINIT;

typedef VOID (*VirtualChannelOpenEvent)(DWORD openHandle, UINT event, LPVOID pData,
                                        UINT32 dataLength, UINT32 totalLength, UINT32 dataFlags);

typedef VirtualChannelOpenEvent PCHANNEL_OPEN_EVENT_FN;

typedef UINT (*VirtualChannelOpen)(LPVOID pInitHandle, LPDWORD pOpenHandle, PCHAR pChannelName,
                                   PCHANNEL_OPEN_EVENT_FN pChannelOpenEventProc);

typedef VirtualChannelOpen PVIRTUALCHANNELOPEN;

typedef UINT (*VirtualChannelClose)(DWORD openHandle);

typedef VirtualChannelClose PVIRTUALCHANNELCLOSE;

typedef UINT (*VirtualChannelWrite)(DWORD openHandle, LPVOID pData, ULONG dataLength,
                                    LPVOID pUserData);

typedef VirtualChannelWrite PVIRTUALCHANNELWRITE;

typedef struct _CHANNEL_ENTRY_POINTS {
   DWORD cbSize;
   DWORD protocolVersion;
   PVIRTUALCHANNELINIT pVirtualChannelInit;
   PVIRTUALCHANNELOPEN pVirtualChannelOpen;
   PVIRTUALCHANNELCLOSE pVirtualChannelClose;
   PVIRTUALCHANNELWRITE pVirtualChannelWrite;
} CHANNEL_ENTRY_POINTS, *PCHANNEL_ENTRY_POINTS;

typedef BOOL (*VirtualChannelEntryMSDN)(PCHANNEL_ENTRY_POINTS pEntryPoints);

typedef VirtualChannelEntryMSDN PVIRTUALCHANNELENTRY;

/*
 * MS compatible SVC plugin interface
 * Reference: http://msdn.microsoft.com/en-us/library/aa383580.aspx
 */

#define CHANNEL_RC_OK 0
#define CHANNEL_RC_ALREADY_INITIALIZED 1
#define CHANNEL_RC_NOT_INITIALIZED 2
#define CHANNEL_RC_ALREADY_CONNECTED 3
#define CHANNEL_RC_NOT_CONNECTED 4
#define CHANNEL_RC_TOO_MANY_CHANNELS 5
#define CHANNEL_RC_BAD_CHANNEL 6
#define CHANNEL_RC_BAD_CHANNEL_HANDLE 7
#define CHANNEL_RC_NO_BUFFER 8
#define CHANNEL_RC_BAD_INIT_HANDLE 9
#define CHANNEL_RC_NOT_OPEN 10
#define CHANNEL_RC_BAD_PROC 11
#define CHANNEL_RC_NO_MEMORY 12
#define CHANNEL_RC_UNKNOWN_CHANNEL_NAME 13
#define CHANNEL_RC_ALREADY_OPEN 14
#define CHANNEL_RC_NOT_IN_VIRTUALCHANNELENTRY 15
#define CHANNEL_RC_NULL_DATA 16
#define CHANNEL_RC_ZERO_LENGTH 17

#define VIRTUAL_CHANNEL_VERSION_WIN2000 1

#define CHANNEL_MAX_COUNT 30

/*
 * Static Virtual Channel Options
 */

enum RDP_SVC_CHANNEL_OPTION {
   CHANNEL_OPTION_SHOW_PROTOCOL = 0x00200000,
   CHANNEL_OPTION_COMPRESS = 0x00400000,
   CHANNEL_OPTION_COMPRESS_RDP = 0x00800000,
   CHANNEL_OPTION_PRI_LOW = 0x02000000,
   CHANNEL_OPTION_PRI_MED = 0x04000000,
   CHANNEL_OPTION_PRI_HIGH = 0x08000000,
   CHANNEL_OPTION_ENCRYPT_CS = 0x10000000,
   CHANNEL_OPTION_ENCRYPT_SC = 0x20000000,
   CHANNEL_OPTION_ENCRYPT_RDP = 0x40000000,
   CHANNEL_OPTION_INITIALIZED = 0x80000000
};

typedef struct tagCHANNEL_PDU_HEADER {
   UINT32 length;
   UINT32 flags;
} CHANNEL_PDU_HEADER, *PCHANNEL_PDU_HEADER;

#define CHANNEL_PDU_LENGTH 1608
#define CHANNEL_CHUNK_LENGTH 1600

/*
 * Static Virtual Channel Events
 */

enum RDP_SVC_CHANNEL_EVENT {
   CHANNEL_EVENT_INITIALIZED = 0,
   CHANNEL_EVENT_CONNECTED = 1,
   CHANNEL_EVENT_V1_CONNECTED = 2,
   CHANNEL_EVENT_DISCONNECTED = 3,
   CHANNEL_EVENT_TERMINATED = 4,
   CHANNEL_EVENT_DATA_RECEIVED = 10,
   CHANNEL_EVENT_WRITE_COMPLETE = 11,
   CHANNEL_EVENT_WRITE_CANCELLED = 12,
   CHANNEL_EVENT_USER = 1000
};

/*
 * Static Virtual Channel Flags
 */

enum RDP_SVC_CHANNEL_FLAG {
   CHANNEL_FLAG_MIDDLE = 0,
   CHANNEL_FLAG_FIRST = 0x01,
   CHANNEL_FLAG_LAST = 0x02,
   CHANNEL_FLAG_ONLY = (CHANNEL_FLAG_FIRST | CHANNEL_FLAG_LAST),
   CHANNEL_FLAG_SHOW_PROTOCOL = 0x10,
   CHANNEL_FLAG_SUSPEND = 0x20,
   CHANNEL_FLAG_RESUME = 0x40,
   CHANNEL_FLAG_FAIL = 0x100
};

#endif
