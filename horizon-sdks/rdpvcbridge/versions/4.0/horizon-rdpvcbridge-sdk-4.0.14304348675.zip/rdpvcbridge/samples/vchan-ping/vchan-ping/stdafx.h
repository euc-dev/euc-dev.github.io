/*
 * Copyright (c) Omnissa, LLC. All rights reserved.
 * This product is protected by copyright and intellectual property laws in the
 * United States and other countries as well as by international treaties.
 * -- Omnissa Restricted
 */

/*
 * stdafx.h
 */

#pragma once

#ifndef _WIN32_WINNT // Allow use of features specific to Windows XP or later.
#   define _WIN32_WINNT                                                                            \
      0x0501 // Change this to the appropriate value to target other versions of Windows.
#endif

#define WIN32_LEAN_AND_MEAN // Exclude rarely-used stuff from Windows headers
#include <windows.h>
#include <wtsapi32.h>

#include <stdio.h>
#include <stdlib.h>
#include <tchar.h>
#include <string>


/*
 * This is all that is needed to port an RDP virtual channel application to use
 * Horizon's RDP virtual channel bridge which allows the application work with
 * Blast, PCoIP and RDP protocols.  Remember to include vdp_rdpvcbridge_import.cpp
 * in your project to act as the import library.
 */
#define MAP_RDPVCBRIDGE
#include "vdp_rdpvcbridge.h"
