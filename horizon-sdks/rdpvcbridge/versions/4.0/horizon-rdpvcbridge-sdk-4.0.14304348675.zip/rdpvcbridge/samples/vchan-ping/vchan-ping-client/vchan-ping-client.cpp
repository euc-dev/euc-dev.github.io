/*
 * Copyright (c) Omnissa, LLC. All rights reserved.
 * This product is protected by copyright and intellectual property laws in the
 * United States and other countries as well as by international treaties.
 * -- Omnissa Restricted
 */

/*
 * vchan-ping-client.cpp
 *
 *    This is the client side of a simple virtual channel application.
 *    The application sends a message to the client side, which then
 *    sends back a response.
 */

#include "stdafx.h"
#include "../vchan-ping/vchan-ping-defs.h"


#if defined(_WIN32)
/*
 *----------------------------------------------------------------------
 *
 * Function DllMain
 *
 * Results:
 *    None
 *
 * Side effects:
 *    None
 *
 *----------------------------------------------------------------------
 */
#   ifdef _MANAGED
#      pragma managed(push, off)
#   endif

BOOL APIENTRY
DllMain(HMODULE hModule,   // IN
        DWORD reason,      // IN
        LPVOID lpReserved) // IN
{
   switch (reason) {
   case DLL_PROCESS_ATTACH:
   case DLL_THREAD_ATTACH:
   case DLL_THREAD_DETACH:
   case DLL_PROCESS_DETACH:
      break;
   }

   return TRUE;
}

#   ifdef _MANAGED
#      pragma managed(pop)
#   endif

#endif // _WIN32


/*
 * Global variables
 */
static CHANNEL_ENTRY_POINTS g_entryPoints;
static LPVOID g_connectionHandle = NULL;
static DWORD g_channelHandle = 0;


/*
 * Fill in whatever logging mechanism you want to use
 */
#define LOG_MESSAGE(...) fprintf(stderr, "*** INFO *** " __VA_ARGS__)
#define LOG_ERROR(...) fprintf(stderr, "*** ERROR *** " __VA_ARGS__)


/*
 *----------------------------------------------------------------------
 *
 * Function ChannelEventProc
 *
 *    Handles read/write events for a virtual channel
 *
 *    For complete details refer to the Microsoft documentation
 *    http://msdn.microsoft.com/en-us/library/aa383573(VS.85).aspx
 *
 * Results:
 *    None
 *
 * Side effects:
 *    None
 *
 *----------------------------------------------------------------------
 */
static VOID VCAPITYPE
ChannelEventProc(DWORD channelHandle, // IN
                 UINT eventType,      // IN
                 LPVOID pData,        // IN
                 UINT32 dataLength,   // IN
                 UINT32 totalLength,  // IN
                 UINT32 dataFlags)    // IN
{
   switch (eventType) {
   case CHANNEL_EVENT_DATA_RECEIVED:
      /*
       * When I receive a specific message from the server side then
       * respond with a message back to the server.  The buffer passed
       * to VirtualChanneWrite() must be valid after this function
       * returns.  I will get a COMPLETE or CANCELLED event when the
       * buffer is no longer being used by the virtual channel API.
       */
      if (strcmp((const char *)pData, SERVER_MESSAGE) == 0) {
         char *pData = ::_strdup(CLIENT_MESSAGE);
         ULONG dataLen = (ULONG)::strlen(pData) + 1;
         LPVOID userData = NULL;

         UINT rc = g_entryPoints.pVirtualChannelWrite(channelHandle, pData, dataLen, userData);
         if (rc != CHANNEL_RC_OK) {
            LOG_ERROR("VirtualChannelWrite(\"%s\") to channel %s(%d) failed (err=%d)\n", pData,
                      VCHAN_NAME, channelHandle, rc);
            ::free(pData);
         }
      }
      break;

   case CHANNEL_EVENT_WRITE_COMPLETE:
   case CHANNEL_EVENT_WRITE_CANCELLED:
      /*
       * When the virtual channel API is done with the buffer
       * that I sent to VirtualChannelWrite() then I need to free it
       */
      ::free(pData);
      break;
   }
}


/*
 *----------------------------------------------------------------------
 *
 * Function ConnectionEventProc
 *
 *    Handles connection events for the remote desktop session.
 *
 *    For complete details refer to the Microsoft documentation
 *    http://msdn.microsoft.com/en-us/library/aa383568(VS.85).aspx
 *
 * Results:
 *    None
 *
 * Side effects:
 *    None
 *
 *----------------------------------------------------------------------
 */
static VOID VCAPITYPE
ConnectionEventProc(LPVOID connectionHandle, // IN
                    UINT eventType,          // IN
                    LPVOID pData,            // IN
                    UINT dataLength)         // IN
{
   UINT rc;

   switch (eventType) {
   case CHANNEL_EVENT_CONNECTED:
      /*
       * You must wait for this event before you can open the channel.
       */
      rc = g_entryPoints.pVirtualChannelOpen(connectionHandle, &g_channelHandle, (PCHAR)VCHAN_NAME,
                                             ChannelEventProc);
      if (rc != CHANNEL_RC_OK) {
         LOG_ERROR("VirtualChannelOpen(\"%s\") failed (err=%d)\n", VCHAN_NAME, rc);
      }
      break;

   case CHANNEL_EVENT_DISCONNECTED:
      g_channelHandle = 0;
      break;

   case CHANNEL_EVENT_INITIALIZED:
   case CHANNEL_EVENT_TERMINATED:
      break;
   }
}


/*
 * Linux does not have .def file - therefore the VirtualChannelEntry
 * symbol will be exported in a mangled manner and subsequent calls
 * to dlsym() that look for this symbol would fail.
 */

#if !defined(_WIN32)
extern "C" {
#endif


/*
 *----------------------------------------------------------------------
 *
 * Function VirtualChannelEntry
 *
 *    Called by the remote desktop protocol to initialize the
 *    RDP virtual channel plugin.
 *
 *    For complete details refer to the Microsoft documentation
 *    http://msdn.microsoft.com/en-us/library/aa383560(VS.85).aspx
 *
 * Results:
 *    None
 *
 * Side effects:
 *    None
 *
 *----------------------------------------------------------------------
 */
VDP_RDPVCBRIDGE_API
BOOL VCAPITYPE
VirtualChannelEntry(PCHANNEL_ENTRY_POINTS pEntryPoints) // IN
{
   /*
    * If the typedefs are not correct then the size of this structure will be wrong
    */
   size_t szChannelEntryPoints = sizeof(void *) == 4 ? 24 /*32-bit*/ : 40 /*64-bit*/;

   if (sizeof(CHANNEL_ENTRY_POINTS) != szChannelEntryPoints) {
      LOG_ERROR("sizeof(CHANNEL_ENTRY_POINTS) is %zd"
                " when it should be %zd\n",
                sizeof(CHANNEL_ENTRY_POINTS), szChannelEntryPoints);
      return FALSE;
   }

   /*
    * You must make a copy the CHANNEL_ENTRY_POINTS structure.
    * Just saving the pointer is not good enough.
    */
   g_entryPoints = *pEntryPoints;


   /*
    * This is an array of channels that we are interested in.
    * For this example there is just a single channel.
    */
   CHANNEL_DEF channelDefs[] = {{VCHAN_NAME, 0}};

   UINT rc =
      g_entryPoints.pVirtualChannelInit(&g_connectionHandle, channelDefs, ARRAYSIZE(channelDefs),
                                        VIRTUAL_CHANNEL_VERSION_WIN2000, ConnectionEventProc);
   if (rc != CHANNEL_RC_OK) {
      LOG_ERROR("VirtualChannelInit(\"%s\") failed (err=%d)\n", VCHAN_NAME, rc);
      return FALSE;
   }

   return TRUE;
}

#if !defined(_WIN32)
}
#endif
