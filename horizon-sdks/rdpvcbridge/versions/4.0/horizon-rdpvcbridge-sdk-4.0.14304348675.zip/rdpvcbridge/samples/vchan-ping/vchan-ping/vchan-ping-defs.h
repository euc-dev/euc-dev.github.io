/*
 * Copyright (c) Omnissa, LLC. All rights reserved.
 * This product is protected by copyright and intellectual property laws in the
 * United States and other countries as well as by international treaties.
 * -- Omnissa Restricted
 */

/*
 * vchan-ping-defs.h
 *
 * This file contains definitions that are common
 * to both the server and client.
 */

#pragma once

/*
 * The name of our virtual channel
 */
#define VCHAN_NAME "VCPING"

#define SERVER_MESSAGE "Ping"
#define CLIENT_MESSAGE "Pong"
