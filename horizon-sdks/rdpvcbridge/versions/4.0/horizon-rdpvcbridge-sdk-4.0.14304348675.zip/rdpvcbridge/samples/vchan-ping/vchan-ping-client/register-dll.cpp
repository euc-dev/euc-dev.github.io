/*
 * Copyright (c) Omnissa, LLC. All rights reserved.
 * This product is protected by copyright and intellectual property laws in the
 * United States and other countries as well as by international treaties.
 * -- Omnissa Restricted
 */

/*
 * register-dll.cpp --
 *
 * Adding these two functions, and exporting them through the .def file,
 * allows us to use RegSvr32.exe to register the DLL as an RDP virtual
 * channel client by making the necessary updates to the registry.
 *
 */

#include "stdafx.h"

#define REG_DLL_HIVE HKEY_LOCAL_MACHINE
#define REG_DLL_KEY _T("Software\\Microsoft\\Terminal Server Client\\Default\\AddIns\\VChanPing")
#define REG_DLL_NAME _T("Name")
#define REG_DLL_ENABLED_OMNISSA _T("Horizon Enabled")
#define REG_DLL_ENABLED_LEGACY _T("View Enabled")
#define REGISTER_PLUGIN_ERROR(x) ((HRESULT)(0x80040200 + (x)))

/*
 * Determine if I'm being compiled as 32 or 64 bit.
 * This is normally done with a preprocessor symbol
 * but I don't want this code to depend on such symbols
 * so that it can be easily added to other projects.
 */
#define HZN_IS_32_BIT (sizeof(void *) == 4)


/*
 *----------------------------------------------------------------------
 *
 * Function HorizonInstalled --
 *
 * Results:
 *    Returns TRUE if requested version of Horizon is installed
 *
 * Side effects:
 *    None
 *
 *----------------------------------------------------------------------
 */
static bool
HorizonInstalled(bool legacy) // IN
{
   HKEY regHive = HKEY_LOCAL_MACHINE;
   const TCHAR *regKey = legacy ? _T("Software\\VMware, Inc.\\VMware VDM\\Client")
                                : _T("Software\\Omnissa\\Horizon\\Client");
   const TCHAR *regValue = _T("BuildNumber");
   DWORD regType = REG_SZ;

   /*
    * You need to look in the registry to find where the
    * dll is installed. For 32-bit appliations make sure
    * to look on non-wow side of the registry.
    */
   HKEY hKey = NULL;
   REGSAM regOpenMode = KEY_QUERY_VALUE | (HZN_IS_32_BIT ? KEY_WOW64_64KEY : 0);

   LONG err = ::RegOpenKeyEx(regHive, regKey, 0, regOpenMode, &hKey);
   if (err != ERROR_SUCCESS)
      return false;

   TCHAR regData[1024];
   DWORD regDataSz = sizeof(regData);
   DWORD regDataType = REG_NONE;

   err = ::RegQueryValueEx(hKey, regValue, NULL, &regDataType, (LPBYTE)regData, &regDataSz);
   RegCloseKey(hKey);
   if (err != ERROR_SUCCESS)
      return false;
   if (regDataType != regType)
      return false;

   return true;
}

static bool
OmnissaHorizonInstalled()
{
   return HorizonInstalled(false);
}

static bool
LegacyHorizonInstalled()
{
   return HorizonInstalled(true);
}


/*
 *----------------------------------------------------------------------
 *
 * Function DllRegisterServer --
 *
 *    Updates the registry to identify the DLL
 *    as an RDP virtual channel plugin.
 *
 * Results:
 *    Returns ERROR_SUCCESS upon success, or an error code
 *    which is displayed by regsvr32
 *
 * Side effects:
 *    None
 *
 *----------------------------------------------------------------------
 */
static HRESULT
DllRegisterServer_(HKEY regHive, const TCHAR *regKey, const TCHAR *regValue,
                   const TCHAR *regKeyEnabled)
{
   /*
    * Get the location of the dll
    */
   HMODULE hMod = NULL;
   LPCSTR moduleAddress = (LPCSTR)DllRegisterServer_;
   DWORD moduleFlags =
      GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS | GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT;
   if (!::GetModuleHandleExA(moduleFlags, moduleAddress, &hMod)) {
      return REGISTER_PLUGIN_ERROR(0);
   }

   TCHAR appPath[MAX_PATH];
   if (!::GetModuleFileName(hMod, appPath, ARRAYSIZE(appPath))) {
      return REGISTER_PLUGIN_ERROR(1);
   }

   /*
    * You need to look in the registry to find where the
    * dll is installed. For 32-bit appliations make sure
    * to look on non-wow side of the registry.
    */
   REGSAM regOpenMode = KEY_ALL_ACCESS | (HZN_IS_32_BIT ? KEY_WOW64_64KEY : 0);

   /*
    * Open/create the key
    */
   LONG winErr;
   HKEY hRegKey;
   DWORD keyCreated;
   winErr = ::RegCreateKeyEx(regHive, regKey, 0, NULL, REG_OPTION_NON_VOLATILE, regOpenMode, NULL,
                             &hRegKey, &keyCreated);
   if (winErr != ERROR_SUCCESS) {
      return REGISTER_PLUGIN_ERROR(2);
   }

   const BYTE *regData = (const BYTE *)appPath;
   DWORD regDataLen = (DWORD)((::_tcslen(appPath) + 1) * sizeof(TCHAR));

   winErr = ::RegSetValueEx(hRegKey, regValue, 0, REG_SZ, regData, regDataLen);
   if (winErr != ERROR_SUCCESS) {
      ::RegCloseKey(hRegKey);
      return REGISTER_PLUGIN_ERROR(3);
   }


   /*
    * Mark the addin as "Horizon Enabled".  If this value doesn't
    * exist or it's set to 0 then Horizon won't load the addin.
    */
   DWORD horizonEnabled = 1;

   regData = (const BYTE *)&horizonEnabled;
   regDataLen = sizeof horizonEnabled;

   winErr = ::RegSetValueEx(hRegKey, regKeyEnabled, 0, REG_DWORD, regData, regDataLen);
   if (winErr != ERROR_SUCCESS) {
      ::RegCloseKey(hRegKey);
      return REGISTER_PLUGIN_ERROR(4);
   }

   ::RegCloseKey(hRegKey);
   return ERROR_SUCCESS;
}

HRESULT __stdcall DllRegisterServer()
{
   if (OmnissaHorizonInstalled()) {
      return DllRegisterServer_(REG_DLL_HIVE, REG_DLL_KEY, REG_DLL_NAME, REG_DLL_ENABLED_OMNISSA);
   }

   if (LegacyHorizonInstalled()) {
      return DllRegisterServer_(REG_DLL_HIVE, REG_DLL_KEY, REG_DLL_NAME, REG_DLL_ENABLED_LEGACY);
   }

   return REGISTER_PLUGIN_ERROR(9);
}


/*
 *----------------------------------------------------------------------
 *
 * Function DllUnregisterServer --
 *
 *    Removes the registry entries added by DllRegisterServer
 *
 * Results:
 *    Returns ERROR_SUCCESS upon success, or an error code
 *    which is displayed by regsvr32
 *
 * Side effects:
 *    None
 *
 *----------------------------------------------------------------------
 */
static HRESULT
DllUnregisterServer_(HKEY regHive, const TCHAR *regKey)
{
   /*
    * You need to look in the registry to find where the
    * dll is installed. For 32-bit appliations make sure
    * to look on non-wow side of the registry.
    */
   REGSAM regOpenMode = KEY_ALL_ACCESS | (HZN_IS_32_BIT ? KEY_WOW64_64KEY : 0);

   HRESULT regErr = ::RegDeleteKeyEx(regHive, regKey, regOpenMode, 0);

   if (regErr != ERROR_SUCCESS && regErr != ERROR_FILE_NOT_FOUND) {
      return REGISTER_PLUGIN_ERROR(0);
   }

   return ERROR_SUCCESS;
}

HRESULT __stdcall DllUnregisterServer()
{
   return DllUnregisterServer_(REG_DLL_HIVE, REG_DLL_KEY);
}
